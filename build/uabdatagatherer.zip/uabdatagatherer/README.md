# UAB Plugin Client

Este é o repositório do Plugin que deve ser instalado no Moodle para que possamos fazer a extração dos dados.