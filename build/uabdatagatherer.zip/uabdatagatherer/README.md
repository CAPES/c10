# UAB Plugin Client

Este é o repositório do Plugin que deve ser instalado no Moodle para que possamos fazer a extração dos dados. Esse documento deverá seguir de guia para ambientar desenvolvedores ou pessoas com perfil técnico que desejam conhecer o plugin e rodar ele em ambiente de desenvolvimento. Caso você esteja interessado em um manual do usuário que mostre como instalar e configurar o plugin basta acessar esse link: https://docs.google.com/document/d/14fPmfdhwzKHORQcAB8FyA330Pg4fjiZBigR6InJeyyY/edit#

## O que é e pra que serve o plugin?
O Projeto do Plugin UAB é uma iniciativa da CAPES em parceria com a UFPE e a Viitra, viabilizando a criação de um plugin para a plataforma Moodle, que tem a finalidade de buscar dados de suas bases e enviar essas informações para um painel gerencial, conhecido como Analytics UAB, onde os gestores possam acompanhar como está o andamento dos cursos UAB ofertados pelas IES de todo o Brasil.

Este software foi baseado na versão de um projeto conhecido como uab-datagatherer, desenvolvido pelo Neto(Colocar nome completo). Através desse plugin podemos extrair, de maneira simples e automatizada, diversas informações e indicadores sobre o desempenho acadêmico dos envolvidos, como: estudantes, professores formadores, professores conteudistas, tutores ead e tutores presenciais.

## Visão Geral
O software é um plugin do tipo “Blocos”, em inglês “blocks”, desenvolvido para a plataforma moodle, todo desenvolvido em PHP e observando os padrões de desenvolvimento presentes na documentação do moodle (https://docs.moodle.org/dev/Blocks). A estrutura básica dos arquivos são: 

- **/array** - diretório onde estão os arquivos estáticos contendo a lista de IES e Cursos vinculados ao programa da UAB (retirada do SisUAB)
- **/db** - diretório contendo as funções de acesso ao banco de dados.
- **/icon_font** - ícones usados pelo plugin
- **/items** - pasta que contém os itens de dados que serão extraídos, cada arquivo implementa uma classe que encapsula a lógica de obtenção do indicador. Todos esses dados estão contidos no contexto de uma disciplina(curso do moodle). A seguir listamos os indicadores e uma breve explicação de cada um. 
  - **base_item.php** - Classe base abstrata comum a todos os itens.
  - **item_avg_days_bef_due.php** - Dados de datas de entrega de atividades e a data que o aluno entregou a atividade.
  - **item_n_access.php** - dados de acesso do aluno no contexto da disciplina.
  - **item_n_assign.php** - dados de entrega de atividade.
  - **item_n_forum.php** - dados de postagens em fóruns.
  - **item_n_grade.php** - dados das notas do aluno.
  - **item_n_message.php** - dados sobre troca de mensagens diretas  no moodle.
  - **item_n_resource.php** - dados sobre o tipo de recurso acessado no ambiente.
- **/js** - conjunto de funções e bibliotecas usadas em Javascript.
- **/lang** - pasta contendo arquivos de tradução com pacotes de línguas. Atualmente apenas em “pt_br” e “en”.
- **cron.php** - endpoint usado para processamento dos dados através de um requisição, ao final gera um arquivo com os dados da coleta.
- **download.php** - endpoint usado para fazer download do arquivo gerado no processamento feito pelo cron.php.
- **get_course_basket.php** - arquivo responsável por montar a response com o upload do json.
- **locallib.php** - arquivo que contém várias funções importantes de chamada de dados e de regra de negócio.
- **request.php** - classe responsável por tratar a fila de requisições 
- **settings.php** - arquivo responsável por montar o form de configuração geral do plugin.
- **styles.css** - folha de estilos do plugin
- **uabcourse_form.php** - formulário de cadastramento de um curso uab.
- **uabcourses_config.php** - listagem dos cursos uab já configurados no plugin.
- **window_execution.php** - classe que verifica janela de execução

## Montando o ambiente para desenvolvimento

É fundamental que você tenha configurado cópias de uma ou mais instâncias de moodle instalado. No repositório do ambiente de homologação criado para o projeto, mostra um exemplo de um ambiente já montando, caso você tenha o dump do banco das apps do IFPE e UPE, caso contrário pode reaproveitar os containers para instalar uma outra versão do moodle. visite aqui: https://gitlab.com/uab-plugin/moodle-complete-structure/-/tree/master .

## Instale o Plugin

Como instalar e configurar o plugin basta acessar esse link: https://docs.google.com/document/d/14fPmfdhwzKHORQcAB8FyA330Pg4fjiZBigR6InJeyyY/edit# .

## Processando a coleta 

Para que uma coleta seja feita em um moodle que tenha o plugin instalado e configurado, você deverá enviar uma requisição para:

`/blocks/uabdatagatherer/cron.php?from_datetime=1607699756&until_datetime=1606235408&server_key=56b69807eef6e7d16f7f9c9bf401abba085cd7b17540964fab46c04e0998403`

Nesse PATH da URL podemos verificar que o arquivo cron.php está executando recebendo 3 parâmetros, que são obrigatórios: 

- **from_datatime** - valor número em formato timestamp que representa **desde** quando os dados gerados do moodle precisão ser coletados.
- **until_datetime** - valor número em formato timestamp que representa **até** quando os dados gerados do moodle precisão ser coletados.
- **server_key** - chave de segurança gerada pelo analytics, obrigatória para autenticar a requisição.

Esse processo pode levar muito tempo, portanto a comunicação entre o analytics e o plugin se dá de forma assíncrona. É necessário de tempos em tempos enviar a requisição para outro path, com o objetivo de fazer download da coleta:

## Algumas possíveis respostas


**Processamento iniciado**

Processamento foi iniciado normalmente.

 Ex.: ```Info: Process started. Send later a new request for get data.```

 **Processamento finalizado**

 O processamento foi finalizado e já pode ser feita a requisição para obters os dados (path download)

 Ex.: ```Success: Data processing was completed. You can now send a request to get the data.```

 **Janela encerrada**

A requisição foi realizada dentro de um horário não permitido pelas configurações do plugin. Então é retornado o horário em que a próxima janela de exibição será liberda. Porém, mesmo com a janela fechada, o pedido de processamento é adicionado à fila.

Ex.: ```Execution window is closed. Will begin at 2021-01-25 23:00. Request added to our queue.```

`/blocks/uabdatagatherer/download.php?from_datetime=1&until_datetime=1606235408&server_key=56b69807eef6e7d16f7f9c9bf401abba085cd7b17540964fab46c04e09984036`

Como observado essa requisição recebe os mesmos parâmetros da anterior e eles servem para saber qual request você está querendo fazer o download, pois o plugin implementa uma fila de requisições, onde cada requisição enviada pelo cron.php passa a ser incluída no final da fila.

## Possíveis respostas



Nesse caso simplesmente o download do arquivo json é realizado.
 

**Caso 2: Dados não foram processados mas pedido está na fila ou seu processamento já foi iniciado**
 

Retornará uma mensagem informando essa situação e qual o status atual desse pedido de processamento, podendo ser “queued” ou “started” 

Ex.: ```“Info: There is no processed data but exists a request with status [ status ] waiting for processing.” ```

**Caso 3: Dados não processados e sem pedido na fila ou com processamento iniciado** 

Retornará uma mensagem informando erro, e pedindo para fazer uma nova requisição de pedido de processamento. 

Ex.: ```“Error: There is no processed data or item queued to be processed. Please send a new processing request for this timestamp.”```


