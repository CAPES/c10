<?php
/**
 * request.php - request class
 *
 * @author Sylvio Freire
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package uabdatagatherer
 */

defined('MOODLE_INTERNAL') || die();
global $CFG, $DB;

require_once ("{$CFG->dirroot}/blocks/uabdatagatherer/locallib.php");

class request {

    function create($status, $from_datetime, $until_datetime) {
        $requestData = [
			"from_datetime" => $from_datetime,
			"until_datetime" => $until_datetime,
			"status" => $status,
			"created_at" => time()
		];
		
		return local_insert_record("block_uabdatagatherer_rquest", $requestData);
    }

    function createQueued($from_datetime, $until_datetime) {
        $queued = $this->getOneByFromDateTimeStatus($from_datetime, $until_datetime, "queued");
        if($queued == null){
            $requestData = [
                "from_datetime" => $from_datetime,
                "until_datetime" => $until_datetime,
                "status" => "queued",
                "created_at" => time()
            ];
            
            return local_insert_record("block_uabdatagatherer_rquest", $requestData);
        }
        return false;
    }

    function get() {
        $query = 'SELECT *
		FROM mdl_block_uabdatagatherer_rquest
        ORDER BY id;';
        return array_values($DB->get_records_sql( $query ));        
    }

    function getOneByStatus($status) {
        global $CFG, $DB;
        $query = "SELECT *
                  FROM {$CFG->prefix}block_uabdatagatherer_rquest r
                  WHERE r.status = '{$status}'
                  ORDER BY r.id 
                  LIMIT 1;";
        
        return array_values($DB->get_records_sql( $query ));
        
    }

    function getOneByFromDateTimeStatus($from_datetime, $until_datetime, $status) {
        global $CFG, $DB;
        $query = "SELECT *
                  FROM {$CFG->prefix}block_uabdatagatherer_rquest r
                  WHERE r.from_datetime = '{$from_datetime}' AND r.until_datetime = '{$until_datetime}' AND r.status = '{$status}'
                  ORDER BY r.id 
                  LIMIT 1;";
        
        return array_values($DB->get_records_sql( $query ));
        
    }
    function getQueuedOrStartedByFromDateTime($from_datetime, $until_datetime) {
        global $CFG, $DB;
        $query = "SELECT *
                  FROM {$CFG->prefix}block_uabdatagatherer_rquest r
                  WHERE r.from_datetime = '{$from_datetime}' AND r.until_datetime = '{$until_datetime}' AND r.status = 'queued' OR r.status = 'started'
                  ORDER BY r.id 
                  LIMIT 1;";
        
        return array_values($DB->get_records_sql( $query ));
        
    }
    function setById($id, $status) {
        $data = [
            "id" => $id,
            "status" => $status
        ];
        return local_update_record("block_uabdatagatherer_rquest", $data);
    }
}