<?php
/**
 * request.php - request class
 *
 * @author Sylvio Freire
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package uabdatagatherer
 */

defined('MOODLE_INTERNAL') || die();
require_once ("{$CFG->dirroot}/blocks/uabdatagatherer/locallib.php");

global $CFG, $DB;

class window_execution {

    function isInWindow($timestart, $timefinish) {
        $now = usertime(time());
        if ($now < $timestart) {        
            //removeCronjobFile();
           return  " Execution window is closed. Will begin at ".date("Y-m-d H:i.",$timestart);
        }
        if ($now > $timefinish) {
            return " Execution window is closed. Next run will be at ".date("Y-m-d H:i.",$timestart + DAYSECS);           
        }

        return true;
    }
}