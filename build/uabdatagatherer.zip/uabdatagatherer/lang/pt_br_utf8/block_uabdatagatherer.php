<?php
//Hack to work in Moodle 1.9
global $CFG;
require_once "{$CFG->dirroot}/blocks/uabdatagatherer/lang/pt_br/block_uabdatagatherer.php";