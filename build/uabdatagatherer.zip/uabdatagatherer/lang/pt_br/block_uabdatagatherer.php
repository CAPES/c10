<?php
/**
 * lang/ptbr_utf8/block_uabdatagatherer.php - File with the labels strings in Brazilian Portuguese
 *
 * @author Francisco Neto
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package uabdatagatherer
 */

$string['title'] = 'Coletor de Dados UAB';
$string['update_course'] = 'Atualize os dados desse curso';
$string['form_students_info'] = 'Informação sobre os status dos estudantes desse curso';
$string['form_course_info'] = 'Informação sobre o curso';
$string['form_status_passed'] = 'Aluno aprovado';
$string['form_status_failed'] = 'Aluno reprovado';
$string['form_status_droped'] = 'Aluno desistiu';
$string['form_status_notstudent'] = 'Não é Aluno';
$string['form_course_data_saved'] = 'Dados do curso foram salvos';
$string['form_course_status'] = 'Marque este item quando estiver pronto para envio';
$string['form_date_time_selector'] = 'Data e hora do final do curso';
$string['form_course_polo'] = 'Polo UAB: ';
$string['form_course_grandearea'] = "Área Acadêmica do curso";
$string['headerconfig'] = 'Configuração do Plugin Coletor de Dados UAB';
$string['descconfig'] = 'COnfiguração necessária para que o plugin uabdatagatherer funcione';
$string['labelserverurl'] = 'URL do Servidor';
$string['descserverurl'] = 'Informe a URL do servidor central para aonde os dados serão enviados';
$string['labelstudentroles'] = 'Papeis que são alunos';
$string['descstudentroles'] = 'Selecionar os papéis que são considerados estudantes nesta instalação do Moodle';
$string['labeltutoreadroles'] = 'Papeis que são Tutores EAD';
$string['desctutoreadroles'] = 'Selecionar os papéis que são considerados Tutores EAD nesta instalação do Moodle';
$string['labelteacherformerroles'] = 'Papeis que são Professores Formadores';
$string['descteacherformerroles'] = 'Selecionar os papéis que são considerados Professores Formadores nesta instalação do Moodle';
$string['labeltutorpresentialroles'] = 'Papeis que são Tutores Presenciais';
$string['desctutorpresentialroles'] = 'Selecionar os papéis que são considerados Tutores Presenciais nesta instalação do Moodle';
$string['labelteachercontentistroles'] = 'Papeis que são Professores Conteudistas';
$string['descteachercontentistroles'] = 'Selecionar os papéis que são considerados Professores Conteudistas nesta instalação do Moodle';
$string['labelrootuabcourses'] = 'Categoria Raiz dos Cursos UAB';
$string['descrootuabcourses'] = 'Selecionar a categoria de curso raiz dos cursos UAB';
$string['labelkey'] = 'Chave de registro no servidor';
$string['desckey'] = 'Chave necessário para se conectar no servidor e transmitir os dados';
$string['labelruntimestart'] = 'Inicio Job';
$string['descruntimestart'] = 'Horário de inicio do cronjob';
$string['labelmaxruntime'] = 'Tempo máximo de execução';
$string['descmaxruntime'] = 'O tempo máximo em que o cronjob pode ficar em execução';
$string['configUabLink'] = 'Adicionar/Remover Cursos UAB';


$string['uabdatagatherer'] = 'uabdatagatherer';
$string['modulename'] = 'uabdatagatherer';
$string['modulenameplural'] = 'uabdatagathererS';
$string['uabdatagathererfieldset'] = 'Exemplo de fieldset customizado';
$string['uabdatagathererintro'] = 'uabdatagatherer Intro';
$string['uabdatagatherername'] = 'uabdatagatherer Name';
$string['uabdatagatherer:respond'] = 'Responer a questões e adicionar novo dado';
$string['config_course'] = 'Configurar Cursos UAB';
$string['config_course_form'] = 'Adicionar Curso';
$string['blockname'] = $string['title'];
$string['pluginname'] = $string['title'];
?>