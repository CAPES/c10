<?php
/**
 * lang/en_utf8/block_uabdatagatherer.php - File with the labels strings in english
 *
 * @author Francisco Neto
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package uabdatagatherer
 */

$string['title'] = 'UAB Data Gatherer';
$string['update_course'] = 'Update this course';
$string['form_students_info'] = 'Information aboute students status in this course';
$string['form_course_info'] = 'Infomation about the course';
$string['form_status_passed'] = 'Student passed';
$string['form_status_failed'] = 'Student failed';
$string['form_status_droped'] = 'Student droped';
$string['form_status_notstudent'] = 'Not Student';
$string['form_course_data_saved'] = 'Course\'s data saved';
$string['form_course_status'] = 'Check this when ready to send';
$string['form_date_time_selector'] = 'Time the course ended';
$string['form_course_polo'] = 'Polo UAB: ';
$string['form_course_grandearea'] = "Academic Field";
$string['headerconfig'] = 'Plugin Configuration Educational Data Gatherer';
$string['descconfig'] = 'Configuration necessary for plugin uabdatagatherer work';
$string['labelserverurl'] = 'Server URL';
$string['descserverurl'] = 'A URL to the central server to send the data';
$string['labelstudentroles'] = 'Students Roles';
$string['descstudentroles'] = 'Roles that are Students in this moodle instalation';
$string['labeltutoreadroles'] = 'Online Tutor Roles';
$string['desctutoreadroles'] = 'Roles that are Online Tutor in this moodle instalation';
$string['labelteacherformerroles'] = 'Former Teacher Roles';
$string['descteacherformerroles'] = 'Roles that are Former Teacher in this moodle instalation';
$string['labeltutorpresentialroles'] = 'Presential Tutor Roles';
$string['desctutorpresentialroles'] = 'Roles that are Presential Tutor in this moodle instalation';
$string['labelteachercontentistroles'] = 'Contentist Teacher Roles';
$string['descteachercontentistroles'] = 'Roles that are Contentist Teacher in this moodle instalation';
$string['labelrootuabcourses'] = 'Root Category for UAB Courses';
$string['descrootuabcourses'] = 'Select the root category that include all uab courses';
$string['labelkey'] = 'Register Key in the server';
$string['desckey'] = 'Key necessary to connect and transmit the data to the server';
$string['labelruntimestart'] = 'Job start';
$string['descruntimestart'] = 'Time to start the job';
$string['labelmaxruntime'] = 'Max runtime';
$string['descmaxruntime'] = 'The max time the job can stay in execution';
$string['configUabLink'] = 'Add/Delete UAB Courses';

$string['uabdatagatherer'] = 'uabdatagatherer';
$string['modulename'] = 'uabdatagatherer';
$string['modulenameplural'] = 'uabdatagathererS';
$string['uabdatagathererfieldset'] = 'Custom example fieldset';
$string['uabdatagathererintro'] = 'uabdatagatherer Intro';
$string['uabdatagatherername'] = 'uabdatagatherer Name';
$string['uabdatagatherer:respond'] = 'Respond to questions e add new data';
$string['config_course'] = 'UAB Course Settings';
$string['config_course_form'] = 'Add Course';
$string['blockname'] = $string['title'];
$string['pluginname'] = $string['title'];
?>