<?php
$ies = array(
		array (
		  'uabid' => 1,
		  'sigla' => 'UFMT',
		  'nome' => 'UNIVERSIDADE FEDERAL DE MATO GROSSO',
		),
		array (
		  'uabid' => 3164,
		  'sigla' => 'IFMT',
		  'nome' => 'INSTITUTO FEDERAL DE EDUCAÇÃO CIÊNCIA E TECNOLOGIA DE MATO GROSSO',
		),
		array (
		  'uabid' => 694,
		  'sigla' => 'UFMS',
		  'nome' => 'FUNDAÇÃO UNIVERSIDADE FEDERAL DE MATO GROSSO DO SUL',
		),
		array (
		  'uabid' => 2,
		  'sigla' => 'UNB',
		  'nome' => 'UNIVERSIDADE DE BRASÍLIA',
		),
		array (
		  'uabid' => 584,
		  'sigla' => 'UFG',
		  'nome' => 'UNIVERSIDADE FEDERAL DE GOIÁS',
		),
		array (
		  'uabid' => 7,
		  'sigla' => 'UFSCAR',
		  'nome' => 'UNIVERSIDADE FEDERAL DE SÃO CARLOS',
		),
		array (
		  'uabid' => 582,
		  'sigla' => 'UFSM',
		  'nome' => 'UNIVERSIDADE FEDERAL DE SANTA MARIA',
		),
		array (
		  'uabid' => 9993,
		  'sigla' => 'FIOCRUZ',
		  'nome' => 'FUNDACAO OSWALDO CRUZ (FIOCRUZ)',
		),
		array (
		  'uabid' => 573,
		  'sigla' => 'UFES',
		  'nome' => 'UNIVERSIDADE FEDERAL DO ESPÍRITO SANTO',
		),
		array (
		  'uabid' => 586,
		  'sigla' => 'UFRJ',
		  'nome' => 'UNIVERSIDADE FEDERAL DO RIO DE JANEIRO',
		),
		array (
		  'uabid' => 693,
		  'sigla' => 'UNIRIO',
		  'nome' => 'UNIVERSIDADE FEDERAL DO ESTADO DO RIO DE JANEIRO',
		),
		array (
		  'uabid' => 1027,
		  'sigla' => 'UENF',
		  'nome' => 'UNIVERSIDADE ESTADUAL DO NORTE FLUMINENSE DARCY RIBEIRO',
		),
		array (
		  'uabid' => 585,
		  'sigla' => 'UFSC',
		  'nome' => 'UNIVERSIDADE FEDERAL DE SANTA CATARINA',
		),
		array (
		  'uabid' => 577,
		  'sigla' => 'UFAL',
		  'nome' => 'UNIVERSIDADE FEDERAL DE ALAGOAS',
		),
		array (
		  'uabid' => 3160,
		  'sigla' => 'IFAL',
		  'nome' => 'INSTITUTO FEDERAL ALAGOAS',
		),
		array (
		  'uabid' => 9999,
		  'sigla' => 'IFPE',
		  'nome' => 'INSTITUTO FED. DE EDUC., CIÊNCIA E TECNOLOGIA DE PERNAMBUCO',
		),
		array (
		  'uabid' => 29,
		  'sigla' => 'UECE',
		  'nome' => 'UNIVERSIDADE ESTADUAL DO CEARÁ',
		),
		array (
		  'uabid' => 568,
		  'sigla' => 'UEMA',
		  'nome' => 'UNIVERSIDADE ESTADUAL DO MARANHÃO',
		),
		array (
		  'uabid' => 9994,
		  'sigla' => 'UFPI',
		  'nome' => 'UNIVERSIDADE FEDERAL DO PIAUÍ',
		),
		array (
		  'uabid' => 730,
		  'sigla' => 'UEPG',
		  'nome' => 'UNIVERSIDADE ESTADUAL DE PONTA GROSSA',
		),
		array (
		  'uabid' => 548,
		  'sigla' => 'UFMA',
		  'nome' => 'UNIVERSIDADE FEDERAL DO MARANHÃO',
		),
		array (
		  'uabid' => 38,
		  'sigla' => 'UEPA',
		  'nome' => 'UNIVERSIDADE DO ESTADO DO PARÁ',
		),
		array (
		  'uabid' => 107,
		  'sigla' => 'UFSJ',
		  'nome' => 'UNIVERSIDADE FEDERAL DE SÃO JOÃO DEL-REI',
		),
		array (
		  'uabid' => 1807,
		  'sigla' => 'IFCE',
		  'nome' => 'INSTITUTO FEDERAL DE EDUCAÇÃO, CIÊNCIA E TECNOLOGIA DO CEARÁ',
		),
		array (
		  'uabid' => 6,
		  'sigla' => 'UFOP',
		  'nome' => 'UNIVERSIDADE FEDERAL DE OURO PRETO',
		),
		array (
		  'uabid' => 579,
		  'sigla' => 'UFPB',
		  'nome' => 'UNIVERSIDADE FEDERAL DA PARAIBA',
		),
		array (
		  'uabid' => 580,
		  'sigla' => 'UFPE',
		  'nome' => 'UNIVERSIDADE FEDERAL DE PERNAMBUCO',
		),
		array (
		  'uabid' => 9995,
		  'sigla' => 'IFSC',
		  'nome' => 'INSTITUTO FEDERAL DE EDUCAÇÃO, CIÊNCIA E TECNOLOGIA DE SANTA CATARINA',
		),
		array (
		  'uabid' => 634,
		  'sigla' => 'UFPEL',
		  'nome' => 'UNIVERSIDADE FEDERAL DE PELOTAS',
		),
		array (
		  'uabid' => 578,
		  'sigla' => 'UFBA',
		  'nome' => 'UNIVERSIDADE FEDERAL DA BAHIA',
		),
		array (
		  'uabid' => 587,
		  'sigla' => 'UFRPE',
		  'nome' => 'UNIVERSIDADE FEDERAL RURAL DE PERNAMBUCO',
		),
		array (
		  'uabid' => 572,
		  'sigla' => 'UFF',
		  'nome' => 'UNIVERSIDADE FEDERAL FLUMINENSE',
		),
		array (
		  'uabid' => 583,
		  'sigla' => 'UFC',
		  'nome' => 'UNIVERSIDADE FEDERAL DO CEARÁ',
		),
		array (
		  'uabid' => 588,
		  'sigla' => 'UTFPR',
		  'nome' => 'UNIVERSIDADE TECNOLÓGICA FEDERAL DO PARANÁ',
		),
		array (
		  'uabid' => 47,
		  'sigla' => 'UEG',
		  'nome' => 'UNIVERSIDADE ESTADUAL DE GOIÁS',
		),
		array (
		  'uabid' => 17,
		  'sigla' => 'UFU',
		  'nome' => 'UNIVERSIDADE FEDERAL DE UBERLÂNDIA',
		),
		array (
		  'uabid' => 3188,
		  'sigla' => 'IFNMG',
		  'nome' => 'INST. FED. EDUC., CIÊNC. E  TECNOL. DO NORTE DE MINAS GERAIS',
		),
		array (
		  'uabid' => 1082,
		  'sigla' => 'IFRN',
		  'nome' => 'INSTITUTO FEDERAL DE EDUCAÇÃO CIÊNCIA E TECNOLOGIA DO RIO GRANDE DO NORTE',
		),
		array (
		  'uabid' => 570,
		  'sigla' => 'UFRN',
		  'nome' => 'UNIVERSIDADE FEDERAL DO RIO GRANDE DO NORTE',
		),
		array (
		  'uabid' => 9996,
		  'sigla' => 'FUFSE',
		  'nome' => 'FUNDAÇÃO UNIVERSIDADE FEDERAL DE SERGIPE',
		),
		array (
		  'uabid' => 569,
		  'sigla' => 'UFPA',
		  'nome' => 'UNIVERSIDADE FEDERAL DO PARÁ',
		),
		array (
		  'uabid' => 1813,
		  'sigla' => 'IFPA',
		  'nome' => 'INSTITUTO FEDERAL DE EDUCAÇÃO, CIÊNCIA E TECNOLOGIA DO PARÁ',
		),
		array (
		  'uabid' => 4,
		  'sigla' => 'UFAM',
		  'nome' => 'UNIVERSIDADE FEDERAL DO AMAZONAS',
		),
		array (
		  'uabid' => 789,
		  'sigla' => 'UFRR',
		  'nome' => 'FUNDAÇÃO UNIVERSIDADE FEDERAL DE RORAIMA',
		),
		array (
		  'uabid' => 699,
		  'sigla' => 'UNIR',
		  'nome' => 'UNIVERSIDADE FEDERAL DE RONDÔNIA',
		),
		array (
		  'uabid' => 1808,
		  'sigla' => 'IFES',
		  'nome' => 'INSTITUTO FEDERAL DE EDUCAÇÃO, CIÊNCIA E TECNOLOGIA DO ESPÍRITO SANTO',
		),
		array (
		  'uabid' => 3849,
		  'sigla' => 'UFT',
		  'nome' => 'FUNDAÇÃO UNIVERSIDADE FEDERAL DO TOCANTINS',
		),
		array (
		  'uabid' => 598,
		  'sigla' => 'UNIFEI',
		  'nome' => 'UNIVERSIDADE FEDERAL DE ITAJUBÁ',
		),
		array (
		  'uabid' => 575,
		  'sigla' => 'UFMG',
		  'nome' => 'UNIVERSIDADE FEDERAL DE MINAS GERAIS',
		),
		array (
		  'uabid' => 576,
		  'sigla' => 'UFJF',
		  'nome' => 'UNIVERSIDADE FEDERAL DE JUIZ DE FORA',
		),
		array (
		  'uabid' => 593,
		  'sigla' => 'CEFET/RJ',
		  'nome' => 'CENTRO FEDERAL DE EDUCAÇÃO TECN. CELSO SUCKOW DA FONSECA',
		),
		array (
		  'uabid' => 574,
		  'sigla' => 'UFRRJ',
		  'nome' => 'UNIVERSIDADE FEDERAL RURAL DO RIO DE JANEIRO',
		),
		array (
		  'uabid' => 591,
		  'sigla' => 'UNIFESP',
		  'nome' => 'UNIVERSIDADE FEDERAL DE SÃO PAULO',
		),
		array (
		  'uabid' => 571,
		  'sigla' => 'UFPR',
		  'nome' => 'UNIVERSIDADE FEDERAL DO PARANÁ',
		),
		array (
		  'uabid' => 581,
		  'sigla' => 'UFRGS',
		  'nome' => 'UNIVERSIDADE FEDERAL DO RIO GRANDE DO SUL',
		),
		array (
		  'uabid' => 1578,
		  'sigla' => 'IFSul',
		  'nome' => 'INSTITUTO FEDERAL DE EDUC., CIÊNC. E TECN. SUL-RIO-GRANDENSE',
		),
		array (
		  'uabid' => 12,
		  'sigla' => 'FURG',
		  'nome' => 'UNIVERSIDADE FEDERAL DO RIO GRANDE',
		),
		array (
		  'uabid' => 830,
		  'sigla' => 'UNIFAP',
		  'nome' => 'UNIVERSIDADE FEDERAL DO AMAPÁ',
		),
		array (
		  'uabid' => 547,
		  'sigla' => 'UERJ',
		  'nome' => 'UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO',
		),
		array (
		  'uabid' => 57,
		  'sigla' => 'UEM',
		  'nome' => 'UNIVERSIDADE ESTADUAL DE MARINGÁ',
		),
		array (
		  'uabid' => 756,
		  'sigla' => 'UESPI',
		  'nome' => 'FUNDACAO UNIVERSIDADE ESTADUAL DO PIAUI FUESPI',
		),
		array (
		  'uabid' => 595,
		  'sigla' => 'UNIFAL',
		  'nome' => 'UNIVERSIDADE FEDERAL DE ALFENAS',
		),
		array (
		  'uabid' => 367,
		  'sigla' => 'UNIMONTES',
		  'nome' => 'UNIVERSIDADE ESTADUAL DE MONTES CLAROS',
		),
		array (
		  'uabid' => 1028,
		  'sigla' => 'UEMS',
		  'nome' => 'UNIVERSIDADE ESTADUAL DE MATO GROSSO DO SUL',
		),
		array (
		  'uabid' => 4925,
		  'sigla' => 'UFABC',
		  'nome' => 'UNIVERSIDADE FEDERAL DO ABC',
		),
		array (
		  'uabid' => 719,
		  'sigla' => 'UNEMAT',
		  'nome' => 'UNIVERSIDADE DO ESTADO DE MATO GROSSO',
		),
		array (
		  'uabid' => 56,
		  'sigla' => 'UNESP-REITORIA',
		  'nome' => 'UNIVERSIDADE ESTADUAL PAULISTA JÚLIO DE MESQUITA FILHO (SEDE)',
		),
		array (
		  'uabid' => 1126,
		  'sigla' => 'UNICENTRO',
		  'nome' => 'UNIVERSIDADE ESTADUAL DO CENTRO-OESTE',
		),
		array (
		  'uabid' => 24,
		  'sigla' => 'UESC',
		  'nome' => 'UNIVERSIDADE ESTADUAL DE SANTA CRUZ',
		),
		array (
		  'uabid' => 40,
		  'sigla' => 'UNEB',
		  'nome' => 'UNIVERSIDADE DO ESTADO DA BAHIA',
		),
		array (
		  'uabid' => 600,
		  'sigla' => 'IFMA',
		  'nome' => 'INSTITUTO FEDERAL DE EDUCAÇÃO, CIÊNCIA E TECNOLOGIA DO MARANHÃO',
		),
		array (
		  'uabid' => 409,
		  'sigla' => 'UPE',
		  'nome' => 'UNIVERSIDADE DE PERNAMBUCO',
		),
		array (
		  'uabid' => 550,
		  'sigla' => 'UEPB',
		  'nome' => 'UNIVERSIDADE ESTADUAL DA PARAIBA',
		),
		array (
		  'uabid' => 4016,
		  'sigla' => 'INES',
		  'nome' => 'INSTITUTO NACIONAL DE EDUCAÇÃO DE SURDOS',
		),
		array (
		  'uabid' => 15015,
		  'sigla' => 'UENP',
		  'nome' => 'UNIVERSIDADE ESTADUAL DO NORTE DO PARANÁ',
		),
		array (
		  'uabid' => 43,
		  'sigla' => 'UDESC',
		  'nome' => 'UNIVERSIDADE DO ESTADO DE SANTA CATARINA',
		),
		array (
		  'uabid' => 15497,
		  'sigla' => 'UNILAB',
		  'nome' => 'UNIVERSIDADE DA INTEGRAÇÃO INTERNACIONAL DA LUSOFONIA AFRO-BRASILEIRA',
		),
		array (
		  'uabid' => 3984,
		  'sigla' => 'UNIVASF',
		  'nome' => 'UNIVERSIDADE FEDERAL DO VALE DO SÃO FRANCISCO',
		),
		array (
		  'uabid' => 592,
		  'sigla' => 'UFLA',
		  'nome' => 'UNIVERSIDADE FEDERAL DE LAVRAS',
		),
		array (
		  'uabid' => 3165,
		  'sigla' => 'IFTM',
		  'nome' => 'INSTITUTO FED. DE EDUC., CIÊNC. E TECN. DO TRIÂNGULO MINEIRO',
		),
		array (
		  'uabid' => 596,
		  'sigla' => 'UFVJM',
		  'nome' => 'UNIVERSIDADE FEDERAL DOS VALES DO JEQUITINHONHA E MUCURI',
		),
		array (
		  'uabid' => 746,
		  'sigla' => 'URCA',
		  'nome' => 'UNIVERSIDADE REGIONAL DO CARIRI',
		),
		array (
		  'uabid' => 1303,
		  'sigla' => 'IFGoiano',
		  'nome' => 'INSTITUTO FEDERAL DE EDUCAÇÃO, CIÊNCIA E TECNOLOGIA GOIANO',
		),
		array (
		  'uabid' => 599,
		  'sigla' => 'IFBA',
		  'nome' => 'INSTITUTO FEDERAL DE EDUCAÇÃO, CIÊNCIA E TECNOLOGIA DA BAHIA',
		),
		array (
		  'uabid' => 4785,
		  'sigla' => 'IFRO',
		  'nome' => 'INSTITUTO FEDERAL DE EDUCAÇÃO CIÊNCIA E TECNOLOGIA DE RONDÔNIA',
		),
		array (
		  'uabid' => 5322,
		  'sigla' => 'UNIPAMPA',
		  'nome' => 'FUNDAÇÃO UNIVERSIDADE FEDERAL DO PAMPA',
		),
		array (
		  'uabid' => 71,
		  'sigla' => 'UERN',
		  'nome' => 'UNIVERSIDADE DO ESTADO DO RIO GRANDE DO NORTE',
		),
		array (
		  'uabid' => 9991,
		  'sigla' => 'UNCISAL',
		  'nome' => 'UNIVERSIDADE ESTADUAL DE CIENCIAS DA SAUDE DE ALAGOAS',
		),
		array (
		  'uabid' => 3184,
		  'sigla' => 'IFRR',
		  'nome' => 'INSTITUTO FEDERAL DE EDUCAÇÃO, CIÊNCIA E TECNOLOGIA DE RORAIMA',
		),
		array (
		  'uabid' => 1812,
		  'sigla' => 'IFAM',
		  'nome' => 'INSTITUTO FEDERAL DE EDUC., CIÊNCIA E TECNOLOGIA DO AMAZONAS',
		),
		array (
		  'uabid' => 609,
		  'sigla' => 'UNIOESTE',
		  'nome' => 'UNIVERSIDADE ESTADUAL DO OESTE DO PARANA',
		),
		array (
		  'uabid' => 3172,
		  'sigla' => 'UEA',
		  'nome' => 'UNIVERSIDADE DO ESTADO DO AMAZONAS',
		),
		array (
		  'uabid' => 9,
		  'sigla' => 'UEL',
		  'nome' => 'UNIVERSIDADE ESTADUAL DE LONDRINA',
		),
		array (
		  'uabid' => 1811,
		  'sigla' => 'IFG',
		  'nome' => 'INSTITUTO FEDERAL DE EDUCACÃO, CIÊNCIA E TECNOLOGIA DE GOIÁS',
		),
		array (
		  'uabid' => 1820,
		  'sigla' => 'IFPI',
		  'nome' => 'INSTITUTO FEDERAL DE EDUCAÇÃO, CIENCIA E TECNOLOGIA DO PIAUÍ',
		),
		array (
		  'uabid' => 688,
		  'sigla' => 'UESB',
		  'nome' => 'UNIVERSIDADE ESTADUAL DO SUDOESTE DA BAHIA',
		),
		array (
		  'uabid' => 666,
		  'sigla' => 'UEFS',
		  'nome' => 'UNIVERSIDADE ESTADUAL DE FEIRA DE SANTANA',
		),
		array (
		  'uabid' => 8,
		  'sigla' => 'UFV',
		  'nome' => 'UNIVERSIDADE FEDERAL DE VIÇOSA',
		),
		array (
		  'uabid' => 4504,
		  'sigla' => 'UFGD',
		  'nome' => 'UNIVERSIDADE FEDERAL DA GRANDE DOURADOS',
		),
		array (
		  'uabid' => 589,
		  'sigla' => 'UFERSA',
		  'nome' => 'UNIVERSIDADE FEDERAL RURAL DO SEMI-ÁRIDO',
		),
		array (
		  'uabid' => 829,
		  'sigla' => 'UNITINS',
		  'nome' => 'UNIVERSIDADE ESTADUAL DO TOCANTINS',
		),
		array (
		  'uabid' => 1036,
		  'sigla' => 'UEMG',
		  'nome' => 'UNIVERSIDADE DO ESTADO DE MINAS GERAIS',
		),
		array (
		  'uabid' => 1166,
		  'sigla' => 'IFPB',
		  'nome' => 'INSTITUTO FEDERAL DE EDUCAÇÃO, CIÊNCIA E TECNOLOGIA  DA PARAÍBA',
		),
		array (
		  'uabid' => 4503,
		  'sigla' => 'UFRB',
		  'nome' => 'UNIVERSIDADE FEDERAL DO RECÔNCAVO DA BAHIA',
		),
		104 => 
		array (
		  'uabid' => 549,
		  'sigla' => 'UFAC',
		  'nome' => 'UNIVERSIDADE FEDERAL DO ACRE',
		),
		array (
		  'uabid' => 5077,
		  'sigla' => 'UERR',
		  'nome' => 'UNIVERSIDADE ESTADUAL DE RORAIMA',
		),
		array (
		  'uabid' => 9992,
		  'sigla' => 'IFSULDEMINAS',
		  'nome' => 'INSTITUTO FEDERAL DE EDUCAÇÃO CIÊNCIA E TECNOLOGIA DO SUL DE MINAS GERAIS',
		),
		array (
		  'uabid' => 1810,
		  'sigla' => 'IFSP',
		  'nome' => 'INSTITUTO FEDERAL DE EDUCAÇÃO, CIÊNCIA E TECNOLOGIA DE SÃO PAULO',
		),
		array (
		  'uabid' => 15522,
		  'sigla' => 'IFAP',
		  'nome' => 'INSTITUTO FEDERAL DE EDUCAÇÃO, CIÊNCIA E TECNOLOGIA DO AMAPÁ',
		),
		array (
		  'uabid' => 1120,
		  'sigla' => 'IFF',
		  'nome' => 'INSTITUTO FEDERAL DE EDUCAÇÃO, CIÊNCIA E TECNOLOGIA FLUMINENSE',
		),
		array (
		  'uabid' => 5036,
		  'sigla' => 'IFC',
		  'nome' => 'INSTITUTO FEDERAL DE EDUCAÇÃO, CIÊNCIA E TECNOLOGIA CATARINENSE',
		),
		array (
		  'uabid' => 3163,
		  'sigla' => 'IFRJ',
		  'nome' => 'INSTITUTO FEDERAL DE EDUCACAO, CIENCIA E TECNOLOGIA DO RIO DE JANEIRO',
		),
		array (
		  'uabid' => 4786,
		  'sigla' => 'IFTO',
		  'nome' => 'INSTITUTO FEDERAL DE EDUCAÇÃO, CIÊNCIA E TECNOLOGIA DO TOCANTINS',
		),
		array (
		  'uabid' => 597,
		  'sigla' => 'UFTM',
		  'nome' => 'UNIVERSIDADE FEDERAL DO TRIÂNGULO MINEIRO',
		),
		array (
		  'uabid' => 95,
		  'sigla' => 'UVA-CE',
		  'nome' => 'UNIVERSIDADE ESTADUAL VALE DO ACARAÚ',
		),
		array (
		  'uabid' => 4098,
		  'sigla' => 'IFFarroup',
		  'nome' => 'INSTITUTO FED. DE EDUC, CIÊNC E TECNOLOGIA FARROUPILHA',
		),
		array (
		  'uabid' => 590,
		  'sigla' => 'UFRA',
		  'nome' => 'UNIVERSIDADE FEDERAL RURAL DA AMAZÔNIA',
		)
);