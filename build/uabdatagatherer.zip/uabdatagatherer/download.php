<?php
/**
 * download.php - Download data for the UAB Data Gatherer
 *
 * The data from the courses are gathered and stored in itens.
 *
 * @author Sylvio Freire
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package uabdatagatherer
 * @param int id The course's id to get the basket from.
 */
require_once('../../config.php');
require_once('locallib.php');
require_once('window_execution.php');
require_once('request.php');

global $CFG;
session_write_close();
ini_set('memory_limit', '1024M');
ignore_user_abort();
set_time_limit(0);

if (isset($_SERVER['REMOTE_ADDR'])) { // Script accessed via the web.
	//get array from url query
	$queryArray = queryToArray($_SERVER['QUERY_STRING']);
	//check required datetime

	if (!isset($queryArray['from_datetime'])) {
		$msg = " Erro: from datetime is required.";
		echo $msg;
		exit;
	}
	
	//check if datetime is a valid timestamp
	if (!isValidTimeStamp($queryArray['from_datetime'])) {
		$msg = " Erro: from datetime is not valid.";
		echo $msg;
		exit;
	}

	if (!isset($queryArray['until_datetime'])) {
		$msg = " Erro: until datetime is required.";
		echo $msg;
		exit;
	}
	
	//check if datetime is a valid timestamp
	if (!isValidTimeStamp($queryArray['until_datetime'])) {
		$msg = " Erro: until datetime is not valid.";
		echo $msg;
		exit;
	}

	set_time_limit(0);
	$web = true;
	// Disable caching
	header("Expires: Fri, 01 Jan 2016 00:00:00 GMT");
	header("Cache-Control: max-age=0, no-cache, must-revalidate, proxy-revalidate");
	// Force txt
	header("Content-Type: text/plain");
} else { // Script called via cron
	$web = false;
}

//Verify if server URL is configured
$serverURL = get_config("block_uabdatagatherer","ServerURL");
if ($serverURL == "") {
	removeCronjobFile();
	$msg = " Erro: ServerURL not configured.";
	if ($web) {
		echo $msg;
		exit;
	} else {
		mtrace($msg);
		return false;
	}
}

// Verify if IES is configured
$iesid = get_config("block_uabdatagatherer","IES");
if ($iesid == 0) {
	removeCronjobFile();
	$msg = " Error: IES not configured.";
	if ($web) {
		echo $msg;
		exit;
	} else {
		mtrace($msg);
		return false;
	}
}

// Verify if uabkey is configured
$uabkey = get_config("block_uabdatagatherer","Key");
if ($uabkey == "") {
	removeCronjobFile();
	$msg = " Error: Verify if server ($serverURL) is ok";
	if ($web) {
		echo $msg;
		exit;
	} else {
		mtrace($msg);
		return false;
	}
}
else if (!isset($queryArray['server_key']) || $queryArray['server_key'] != $uabkey) {
	$msg = " Erro: invalid key.";
	echo $msg;
	exit;
}

// Get list of courses configured
if (! $courses = array_values(getAllCoursesConfigured()) ) {
	$msg = " Error: Courses not configured.";
	if ($web) {
		echo $msg;
		exit;
	} else {
		mtrace($msg);
		return false;
	}
}

$request = new Request();
$requestItem = $request->getLastByFromDateTimeStatus($queryArray['from_datetime'], $queryArray['until_datetime'], "processed");

if ($requestItem == null) {	

	$queuedOrStarted = $request->getQueuedOrStartedByFromDateTime($queryArray['from_datetime'], $queryArray['until_datetime']);

	if($queuedOrStarted == null) {
		$msg = "Error: There is no processed data or item queued to be processed. Please send a new processing request for this timestamp.";
	}
	else {
		$msg = sprintf("Info: There is no processed data but exists a request with status [ %s ] waiting for processing.", $queuedOrStarted[0]->status);
	}
	if ($web) {
		echo $msg;
		exit;
	} else {
		mtrace($msg);
		return false;
	}
}

if(downloadJson($requestItem) == false){
	$msg = " Error: File data not exists for this timestamp. Please send a new process request.";
	if ($web) {
		echo $msg;
		exit;
	} else {
		mtrace($msg);
		return false;
	}
}
else{
	if ($web) {
		// echo $msg;
		exit;
	} else {
		// mtrace($msg);
		return true;
	}
}