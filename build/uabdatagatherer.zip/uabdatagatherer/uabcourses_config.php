<?php
/**
 * Script to let a admin manage their UAB Courses.
 * @author Sylvio, Thiago Araujo
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package uabdatagatherer
 * 
 */

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/tablelib.php');
require_once('locallib.php');

global $COURSE;
require_login();
$isDeleted = false;
$coursecontext = get_context_instance(CONTEXT_COURSE, $COURSE->id);

if(!has_capability('block/uabdatagatherer:respond', $coursecontext)) {    
    $homeurl = new moodle_url('/');
    redirect($homeurl);  
} 

$queryArray = queryToArray($_SERVER['QUERY_STRING']);

if($queryArray && isset($queryArray['delete'])){
    local_delete_records('block_uabdatagatherer_course', 'id', $queryArray['delete']);
    local_delete_records('block_uabdatagatherer_subjec', 'uab_id', $queryArray['uabid']);
    $isDeleted = true;
}

require_once ("{$CFG->dirroot}/blocks/uabdatagatherer/locallib.php");
require ("{$CFG->dirroot}/blocks/uabdatagatherer/array/ies.php");
require ("{$CFG->dirroot}/blocks/uabdatagatherer/array/polo.php");
require ("{$CFG->dirroot}/blocks/uabdatagatherer/array/course.php");

$strmanage = get_string('config_course', 'block_uabdatagatherer');

$PAGE->set_pagelayout('standard');
$PAGE->set_title($strmanage);
$PAGE->set_heading($strmanage);
$PAGE->requires->jquery();
$PAGE->requires->jquery_plugin('ui');
$PAGE->requires->jquery_plugin('ui-css');
 
$coursesettings = new moodle_url('/blocks/uabdatagatherer/uabcourses_config.php');
$PAGE->navbar->add(get_string('blocks'));
$PAGE->navbar->add(get_string('pluginname', 'block_uabdatagatherer'));
$PAGE->navbar->add(get_string('config_course', 'block_uabdatagatherer'), $coursesettings);
echo $OUTPUT->header();

$courses = local_get_records("block_uabdatagatherer_course");

echo '<div id="uab_result" class="uab_result">';
echo $isDeleted ? '<span id="uabSuccess" style="color: red;"><b>Curso UAB removido com sucesso!</b></span>' : '';
echo '</div>';
if(!empty($courses)){
    $table = new html_table();
    $table->head = array('Listagem de Cursos','Editar','Excluir');
    foreach($courses as $item){
        $row = new html_table_row();
        $cell_name = new html_table_cell($item->name);
        $cell_edit = new html_table_cell('<a href="'."uabcourse_form.php?uabid=".$item->uab_id."&id=".$item->id.'"><img src="icon_font/img/edit.png" width="16px" height="16px"></img></a>');
        $cell_exclude = new html_table_cell('<a title="Excluir" href="uabcourses_config.php?delete='.$item->id."&uabid=$item->uab_id".'"  onClick="javascript:return confirm(\'Deseja excluir este curso?\');"><img src="icon_font/img/remove.png" width="16px" height="16px"></img></a>');
        $cell_exclude->attributes['class'] = 'icon';
        $cell_exclude->attributes['align'] = 'right';
        
        $row->cells[] = $cell_name;
        $row->cells[] = $cell_edit;
        $row->cells[] = $cell_exclude;

        $table->data[] = $row;
        // $table->data[] = array($item['nome'],'<a href="'."link".'">Editar</a>','<a href="'.$item['nome'].'" class="delete">Excluir</a>');
    }
    echo html_writer::table($table);
}
else{
    echo "<div>Nenhum curso configurado.";
}
    ?>
    <div id="dialog" title="Confirmação de Exclusão">
        Deseja deletar as configurações desse curso?
    </div>

 
<script>
    $(document).ready(function() {
        $("#dialog").dialog({
            autoOpen: false,
            modal: true
        });
    });

    $(".delete").click(function(e) {
        e.preventDefault();
        var targetUrl = $(this).attr("href");

        $("#dialog").dialog({
            position: ['center', 'center', 'center'],
            buttons : {
                "Sim" : function() {
                    window.location.href = targetUrl;
                },
                "Não" : function() {
                    $(this).dialog("close");
                }
            }
        });

        $("#dialog").dialog("open");
    });
</script>
 <?php
$coursesettings_form = new moodle_url('/blocks/uabdatagatherer/uabcourse_form.php');
echo '<form action="'.$coursesettings_form.'" method="get">
    <input type="submit" value="Adicionar um novo curso" id="frm1_submit" class="form-submit"/>
</form>';
echo $OUTPUT->footer();
?>
