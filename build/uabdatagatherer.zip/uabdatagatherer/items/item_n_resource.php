<?php
/**
 * item_n_forum.php - Class file to item n_post_forum
 *
 * @author Thiago Araújo
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package uabdatagatherer
 */

defined('MOODLE_INTERNAL') || die();
global $CFG;
require_once ("{$CFG->dirroot}/blocks/uabdatagatherer/locallib.php");
require_once('base_item.php');

class uabdatagatherer_item_n_resource extends uabdatagatherer_item_base {

	function getLabel() {
		return "n_resource";
	}

	function getDescription() {
		return "Total of resource types sent to ead and former teacher on the LMS";
	}

	function calculate ($ids) {
		global  $CFG;
		
		$context = get_context_instance( CONTEXT_COURSE, $this->courseid );
		$array_roles = [			
			'tutors_ead' => $ids['tutors_ead'],
			'teacher_formers' => $ids['teacher_formers']
		];
		

		$queryContext = "SELECT id FROM {$CFG->prefix}context c WHERE c.path LIKE '%/{$context->id}/%'";
		$result_contexts = local_get_recordset_sql($queryContext);

		foreach ($array_roles as $role => $users){
			for ($i=0; $i < count($users); $i++)
			{
				$id = $users[$i];
				$resourses = array();
				
				foreach ($result_contexts as $key => $contextObject) {
					$query = "SELECT m.mimetype, count(m.mimetype) as total
							FROM {$CFG->prefix}files m 
							WHERE m.userid = {$id['user_id']} AND m.timecreated >= {$this->timestamp_last} 
							AND m.timecreated <= {$this->timestamp_until} 
							AND m.contextid = {$contextObject->id}
							GROUP BY m.mimetype";
					$rs = local_get_recordset_sql($query);

					foreach ($rs as $result) {
						if (!$result->mimetype == NULL)
							$resourses[$result->mimetype] = $result->total;
						else
							$resourses['undefined'] = $result->total;
					}

					$rs->close();
				}
				
				$CFG->uabdata['courses'][$this->array_index]['subjects'][$this->subject_index]['users'][$role][$i]['n_resource'] = $resourses;
				
			}
			
		}
		
	}
}