<?php
/**
 * item_n_forum.php - Class file to item n_post_forum
 *
 * @author Thiago Araújo
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package uabdatagatherer
 */

defined('MOODLE_INTERNAL') || die();
global $CFG;
require_once ("{$CFG->dirroot}/blocks/uabdatagatherer/locallib.php");
require_once('base_item.php');

class uabdatagatherer_item_n_forum extends uabdatagatherer_item_base {

	function getLabel() {
		return "n_forum";
	}

	function getDescription() {
		return "Total of forums interection postings commeting/answering and opening discussion";
	}

	function calculate ($ids) {
		global  $CFG;
		$array_roles = [			
			'students' => $ids['students'],
			'tutors_ead' => $ids['tutors_ead'],
			'teacher_formers' => $ids['teacher_formers']
		];

		$a_students = array();
		foreach ($array_roles as $role => $users){
			for ($i=0; $i < count($users); $i++)
			{
				$id = $users[$i];
				$student = new stdClass();
				// Pegar Discussão
				$query = "SELECT timemodified as timecreated
							FROM {$CFG->prefix}forum_discussions d
							WHERE d.course = {$this->courseid} AND d.userid = {$id['user_id']} AND d.timemodified >= {$this->timestamp_last} AND d.timemodified <= {$this->timestamp_until}";
				
				$disc = array();
				$rs = local_get_recordset_sql($query);	
					
				foreach ($rs as $row) {
					$disc[] = intval($row->timecreated);
				}
				$rs->close();
				
				
				// Pegar Posts
				$query2 = "SELECT p.created as timecreated
							FROM {$CFG->prefix}forum_discussions d
							INNER JOIN {$CFG->prefix}forum_posts p ON d.id = p.discussion AND p.created >= {$this->timestamp_last} AND p.created <= {$this->timestamp_until}
							WHERE d.course = {$this->courseid} AND p.userid = {$id['user_id']}";

				$posts = array();
				$rs = local_get_recordset_sql($query2);	
					
				foreach ($rs as $row) {
					$posts[] = intval($row->timecreated);
				}
				$rs->close();
				
				$n_forum = array_merge($disc,$posts);

				$CFG->uabdata['courses'][$this->array_index]['subjects'][$this->subject_index]['users'][$role][$i]['n_forum'] = $n_forum;
			}
		}

	}
}