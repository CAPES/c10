<?php
/**
 * item_n_access.php - Class file to item n_access
 *
 * @author  Thiago Araújo
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package uabdatagatherer
 */

defined('MOODLE_INTERNAL') || die();
global $CFG;
require_once ("{$CFG->dirroot}/blocks/uabdatagatherer/locallib.php");
require_once('base_item.php');

class uabdatagatherer_item_t_grade extends uabdatagatherer_item_base {

	function getLabel() {
		return "t_grade";
	}

	function getDescription() {
		return "List of all grade activities of an user.";
	}

	function calculate ($ids) {
        global  $CFG, $OBJECT;
        $array_roles = [
			'students' => $ids['students']
		];
        $SQL_table_grades="{$CFG->prefix}grade_grades";
        $SQL_table_items="{$CFG->prefix}grade_items";
		
        $a_students = array();
        foreach ($array_roles as $role => $users){
		    for ($i=0; $i < count($users); $i++){
                $id = $users[$i]["user_id"];
                $student = new stdClass();
                /* SELECT i.courseid, g.userid, g.rawgrade, g.rawgrademax, g.finalgrade
                    FROM mdl_grade_items as i
                    INNER JOIN mdl_grade_grades as g ON i.id = g.itemid and g.userid = 1417 and i.courseid = 149 */

                $query = "SELECT i.id, g.rawgrade, g.rawgrademax, g.finalgrade FROM {$SQL_table_items} as i INNER JOIN  {$SQL_table_grades} as g ON i.id = g.itemid AND g.userid = {$id} AND i.courseid = {$this->courseid} AND g.timemodified >= {$this->timestamp_last}" ;

                $grades_result = local_get_recordset_sql($query);
                $grades = array();
                foreach ($grades_result as $grade) {
                    if (is_null($grade->finalgrade)){
                        $grades[] = "0,00";
                    }else{
                        $final_grade = ($grade->finalgrade/$grade->rawgrademax)*10;
                        $final_grade = number_format($final_grade, 2, ',', '.');
                        $grades[] = $final_grade;
                    }
                }
                
                $OBJECT->uabdata['courses'][$this->array_index]['subjects'][$this->subject_index]['users'][$role][$i]['n_grade'] = $grades;
                
            }
        }
	}
}