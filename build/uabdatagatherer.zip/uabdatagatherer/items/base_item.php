<?php
/**
 * base_item.php - Base class to be used to create the itens class to compose the basket.
 *
 * @author Francisco Neto
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package uabdatagatherer
 */

defined('MOODLE_INTERNAL') || die();
global $CFG;
require_once ("{$CFG->dirroot}/blocks/uabdatagatherer/locallib.php");

abstract class uabdatagatherer_item_base {
	var $itemid;
	var $courseid;
	var $student_values;
	var $timestamp_last;
	var $subject_index;
	var $array_index;

	/**
	 * Return a string with the label of the item.
	 */
	abstract function getLabel() ;

	/**
	 * Return a string with the description of the item.
	 */
	abstract function getDescription() ;

	function uabdatagatherer_item_base ($courseid="", $array_index, $subject_index, $array_students) {

		if (empty($courseid)) return NULL;
		
		$this->courseid = $courseid;
		$this->subject_index = $subject_index;
		$this->array_index = $array_index;
		$this->student_status = $array_students;

		// if (! local_record_exists_select("block_uabdatagatherer_items", "label = '".$this->getLabel()."'")) { // item not in table
		// 	$item = new stdClass();
		// 	$item->label = $this->getLabel();
		// 	$this->itemid = local_insert_record("block_uabdatagatherer_items",$item,true);
		// } else {
		// 	$item = local_get_record("block_uabdatagatherer_items", "label", $this->getLabel());
		// 	$this->itemid = $item->id;
		// }
		$this->generateData();
		// $this->save();
	}

	/**
	 * Calculate the valor of the item for every student in the course.
	 *
	 * @param array $ids This function receive a array with a list of students userids.
	 * @return mixed Return a array of objects, where every object have the student's userid and the value calculated for this item.
	 */
	abstract function calculate ($ids) ;

	/**
	 * Save the data in the database.
	 */
	function save () {
		//local_delete_records("block_uabdatagatherer_basket", "courseid", $this->courseid);
		foreach ($this->student_values as $student) {
			//echo "userid ".$student->userid." courseid = ".$this->courseid." itemid = ".$this->itemid." value = ".$student->value."<br>\n";
			$b_item = new object();
			$b_item->userid = $student->userid;
			$b_item->courseid = $this->courseid;
			$b_item->itemid = $this->itemid;
			if (is_float($student->value)) {
				$b_item->value = round($student->value,5);
			} else {
				$b_item->value = $student->value;
			}
			//local_delete_records("block_uabdatagatherer_basket", "courseid", $this->courseid, "itemid", $this->itemid);
			local_insert_record("block_uabdatagatherer_basket",$b_item);
		}
	}

	/**
	 * Generate the data.
	 */
	function generateData () {
		global $OBJECT;

		// $edg = new uabdatagatherer_course($this->courseid);
		//$this->timestamp_last = $edg->timestamp_last;
		$this->timestamp_last = $OBJECT->uabdata['from_datetime'];
		$this->timestamp_until = $OBJECT->uabdata['until_datetime'];
		//$this->timestamp_last = time();
		$ids = array();

		// TODO acrescentar check no $edg->student_status
		// foreach ($edg->student_status as $student) {
		// 	$ids[] = [
		// 		'id' => $student->userid,
		// 		'username' => $student->username
		// 	];
		// }

		$this->student_values = $this->calculate($this->student_status);
	}
}