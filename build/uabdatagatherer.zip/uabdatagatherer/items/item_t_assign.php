<?php
/**
 * item_avg_days_bef_due.php - Class file to item avg_days_bef_due
 *
 * @author Francisco Neto
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package uabdatagatherer
 */

defined('MOODLE_INTERNAL') || die();
global $CFG;
require_once ("{$CFG->dirroot}/blocks/uabdatagatherer/locallib.php");
require_once('base_item.php');

class uabdatagatherer_item_t_assign extends uabdatagatherer_item_base {

	function getLabel() {
		return "t_assign";
	}

	function getDescription() {
		return "Average of difference between deadline and actual exercise upload";
	}

	function calculate ($ids) {
		global  $CFG, $OBJECT;	
		$array_roles = [
			'students' => $ids['students'],
			'tutors_presential' => $ids['tutors_presential'],
			'teacher_contentist' => $ids['teacher_contentist'],
		];

		$a_assigments = array();
		if (MOODLE_DETECTED_VERSION >= 23) {// table assign exist only in versions 2.3 or older
			$query = "SELECT COUNT(*) as total FROM {$CFG->prefix}assign a WHERE a.course = {$this->courseid} AND a.duedate >= {$this->timestamp_last} AND a.duedate <= {$this->timestamp_until}";				  
			
				$total = local_get_recordset_sql($query);
			
				$local_total = 0;
				foreach ($total as $value) {
					$local_total = $value->total;	
				}
				if ($total) {
					$total->close();
				}
				$totalAssigns = intval($local_total);

		}
		foreach ($array_roles as $role => $users){
			for ($i=0; $i < count($users); $i++) {
				$student = new stdClass();
				$id = $users[$i];					
								
				if (MOODLE_DETECTED_VERSION >= 23) {// table assign exist only in versions 2.3 or older					
					$query = " SELECT a.id as assignment_id, a.duedate as due_date, asub.timemodified as delivered_date, agrad.grade FROM {$CFG->prefix}user u LEFT JOIN {$CFG->prefix}assign_submission asub ON asub.userid = u.id LEFT JOIN {$CFG->prefix}assign a ON asub.assignment = a.id LEFT JOIN {$CFG->prefix}assign_grades agrad ON agrad.assignment = a.id AND agrad.userid={$id['user_id']} WHERE a.course = {$this->courseid} AND u.id={$id['user_id']}";
										
					$assigns = array();
					$rs = local_get_recordset_sql($query);	
					
					foreach ($rs as $assign) {
						$assigns[] =  $assign;
					}
					$rs->close();
					
					
					if(count($assigns) < $totalAssigns){
						$difference = $totalAssigns - count($assigns);
						for($index = 0; $index < $difference ; $index++){
							$object = new stdClass();
							$object->delivered_date = null;
							$object->due_date = null;
							$object->grade = null;
							$assigns[] = $object;
						}
					}			
				} else { //moodle does not have table assign (todo)
					$a_assigments = null;
				}  
				
				$OBJECT->uabdata['courses'][$this->array_index]['subjects'][$this->subject_index]['users'][$role][$i]['assign'] = $assigns;
			}
		}
	}
}