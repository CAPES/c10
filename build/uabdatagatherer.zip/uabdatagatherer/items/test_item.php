<?php
/**
 * test_item.php - File to do some tests in items
 *
 * @author Francisco Neto
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package uabdatagatherer
 */


require_once('../../../config.php');
require_once('../locallib.php');
global $CFG;

// When testing comment the next line
error("Line not commented in test file");

// Include the item to be tested and make some tests
//require_once('item_avg_freq_access.php');
//$test = new uabdatagatherer_item_avg_freq_access(85);
//require_once('item_n_access.php');
//$test = new uabdatagatherer_item_n_access(85);
//require_once('item_n_days_first_access.php');
//$test = new uabdatagatherer_item_n_days_first_access(85);
//require_once('item_n_post_ask_stu.php');
//$test = new uabdatagatherer_item_n_post_ask_stu(85);
//require_once('item_n_post_ans_stu.php');
//$test = new uabdatagatherer_item_n_post_ans_stu(85);
//require_once('item_n_msg_ask.php');
//$test = new uabdatagatherer_item_n_msg_ask(85);
//require_once('item_n_msg_ans.php');
//$test = new uabdatagatherer_item_n_msg_ans(85);
//require_once('item_n_msg_ask_teacher.php');
//$test = new uabdatagatherer_item_n_msg_ask_teacher(85);
//require_once('item_n_msg_ans_teacher.php');
//$test = new uabdatagatherer_item_n_msg_ans_teacher(85);
//require_once('item_n_assign.php');
//$test = new uabdatagatherer_item_n_assign(85);
//require_once('item_avg_days_bef_due.php');
//$test = new uabdatagatherer_item_avg_days_bef_due(85);
//echo "Resultado:<br>\n";
//foreach ($test->student_values as $item ) {
//	echo "userid: {$item->userid} value: {$item->value}\n<br>";
//}

require_once('countlog_item.php');
create_count_log_itens (2);
