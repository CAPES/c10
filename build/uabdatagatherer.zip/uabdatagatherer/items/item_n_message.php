<?php
/**
 * item_n_forum.php - Class file to item n_post_forum
 *
 * @author Thiago Araújo
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package uabdatagatherer
 */

defined('MOODLE_INTERNAL') || die();
global $CFG;
require_once ("{$CFG->dirroot}/blocks/uabdatagatherer/locallib.php");
require_once('base_item.php');

class uabdatagatherer_item_n_message extends uabdatagatherer_item_base {

	function getLabel() {
		return "n_message";
	}

	function getDescription() {
		return "Total of message interection sent to each role on the LMS";
	}

	function calculate ($ids) {
		global  $CFG, $OBJECT;

		$context = get_context_instance( CONTEXT_COURSE, $this->courseid );
		$array_roles = [			
			'students' => $ids['students'],
			'tutors_ead' => $ids['tutors_ead'],
			'teacher_formers' => $ids['teacher_formers'],
			'tutors_presential' => $ids['tutors_presential'],
			'teacher_contentist' => $ids['teacher_contentist'],
		];
		
		// $n_message = (object) array(
		// 	'to_students' => null,
		// 	'to_tutors_ead' => null,
		// 	'to_teacher_formers' => null,
		// 	'to_tutors_presential' => null,
		// 	'to_teacher_contentist' => null
		// );

		foreach ($array_roles as $role => $users){
			for ($i=0; $i < count($users); $i++)
			{
				$id = $users[$i];
				$student = new stdClass();
				$query = "SELECT m.useridto, m.timecreated, r.roleid FROM {$CFG->prefix}message_read m  LEFT JOIN {$CFG->prefix}role_assignments r ON m.useridto = r.userid AND r.contextid={$context->id} WHERE m.useridfrom = {$id['user_id']} AND m.timecreated >= {$this->timestamp_last} AND m.timecreated <= {$this->timestamp_until}";

				$messages = array();
				$rs = local_get_recordset_sql($query);	
				
				foreach ($rs as $item) {
					$messages[] = (array)$item;
				}
				$rs->close();

				$to_students = array();
				foreach ($array_roles as $m_role => $users2) {
					if($m_role == 'students'){
						$m_roles = explode(",", get_config("block_uabdatagatherer","StudentRoles"));
					}elseif($m_role == 'tutor_ead'){
						$m_roles = explode(",", get_config("block_uabdatagatherer","TutorEADRoles"));
					}elseif($m_role == 'teacher_formers'){ 
						$m_roles = explode(",", get_config("block_uabdatagatherer","TeacherFormerRoles"));
					}elseif($m_role == 'tutors_presential'){ 
						$m_roles = explode(",", get_config("block_uabdatagatherer","TutorPresentialRoles"));
					}elseif($m_role == 'teacher_contentist'){
						$m_roles = explode(",", get_config("block_uabdatagatherer","TeacherContentist"));
					}
					foreach ($m_roles as $key => $l_role) {
						$to_role = array_filter($messages, function ($var) use ($l_role) {
							return $var['roleid'] == $l_role;
						});
					}
					$n_message['to_'.$m_role] = array_column($to_role, 'timecreated');
				}
				$to_role = array_filter($messages, function ($var){
					return $var['roleid'] == NULL;
				});
				$n_message['to_others'] = array_column($to_role, 'timecreated');
				$OBJECT->uabdata['courses'][$this->array_index]['subjects'][$this->subject_index]['users'][$role][$i]['t_message'] = $n_message;
			}
		}
	}
}