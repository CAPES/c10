<?php
/**
 * item_n_access.php - Class file to item n_access
 *
 * @author Francisco Neto
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package uabdatagatherer
 */

defined('MOODLE_INTERNAL') || die();
global $CFG;
require_once ("{$CFG->dirroot}/blocks/uabdatagatherer/locallib.php");
require_once('base_item.php');

class uabdatagatherer_item_n_access extends uabdatagatherer_item_base {

	function getLabel() {
		return "n_access";
	}

	function getDescription() {
		return "Total number of access the studant have in the course";
	}

	function calculate ($ids) {
		global  $CFG, $OBJECT;
		$array_roles = [			
			'students' => $ids['students'],
			'tutors_ead' => $ids['tutors_ead'],
			'teacher_formers' => $ids['teacher_formers'],
			'tutors_presential' => $ids['tutors_presential'],
			'teacher_contentist' => $ids['teacher_contentist'],
		];
		if (MOODLE_DETECTED_VERSION < 26) {
			$SQL_table="{$CFG->prefix}log";
			$SQL_course="course";
			$SQL_time="time";
		} else {
			$SQL_table="{$CFG->prefix}logstore_standard_log";
			$SQL_course="courseid";
			$SQL_time="timecreated";
		}

		foreach ($array_roles as $role => $users){
			for ($i=0; $i < count($users); $i++)
			{
				$id = $users[$i];
				$student = new stdClass();
				$query = "SELECT {$SQL_time} as total FROM {$SQL_table} WHERE {$SQL_course} = {$this->courseid} AND userid = {$id['user_id']} AND {$SQL_time} >= {$this->timestamp_last} AND {$SQL_time} <= {$this->timestamp_until}";
				$result = local_get_recordset_sql($query);
				error_log("DEBUG: ".$query);
				$n_access = array();
				foreach ($result as $value) {
					$n_access[] = $value->total;
				}
				if ($result) {
					$result->close();
				}
								
				$OBJECT->uabdata['courses'][$this->array_index]['subjects'][$this->subject_index]['users'][$role][$i]['n_access'] = $n_access;
				//error_log("DEBUG: ".$OBJECT->uabdata['courses'][$this->array_index]['subjects'][$this->subject_index]['users'][$role][$i]['n_access'] = $n_access);
			}
			//die;
		}			
	}
}