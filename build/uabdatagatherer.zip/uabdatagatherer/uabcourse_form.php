<?php
/**
 * Script to let a admin manage their UAB Courses.
 * @author Thiago Araujo
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package uabdatagatherer
 */

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/tablelib.php');
require_once('locallib.php');

require_login();

$table_subject = "block_uabdatagatherer_subjec";
$table_course = "block_uabdatagatherer_course";

$coursecontext = get_context_instance(CONTEXT_COURSE, $COURSE->id);

if(!has_capability('block/uabdatagatherer:respond', $coursecontext)) {    
    $homeurl = new moodle_url('/');
    redirect($homeurl);  
} 

require_once ("{$CFG->dirroot}/blocks/uabdatagatherer/locallib.php");
require ("{$CFG->dirroot}/blocks/uabdatagatherer/array/ies.php");
require ("{$CFG->dirroot}/blocks/uabdatagatherer/array/polo.php");
require ("{$CFG->dirroot}/blocks/uabdatagatherer/array/course.php");

$strmanage = get_string('config_course', 'block_uabdatagatherer');

$PAGE->set_pagelayout('standard');
$PAGE->set_title($strmanage);
$PAGE->set_heading($strmanage);

$coursesettings = new moodle_url('/blocks/uabdatagatherer/uabcourses_config.php');
$coursesettings_form = new moodle_url('/blocks/uabdatagatherer/uabcourse_form.php');
$PAGE->navbar->add(get_string('blocks'));
$PAGE->navbar->add(get_string('pluginname', 'block_uabdatagatherer'));
$PAGE->navbar->add(get_string('config_course', 'block_uabdatagatherer'), $coursesettings);
$PAGE->navbar->add(get_string('config_course_form', 'block_uabdatagatherer'), $coursesettings_form);
echo $OUTPUT->header();


// $PAGE->requires->js('/blocks/uabdatagatherer/js/jquery.min.js');
// $PAGE->requires->js('/blocks/uabdatagatherer/js/jquery.transfer.js');


$uabCourseId = $_GET['uabid'];
$rootCategory = $_GET['rootcategory'];
$reload = $_GET['reload'];

$rootUabCourses = explode(",", get_config("block_uabdatagatherer","RootUABCourses"));
if ($rootUabCourses[0] == ""){
  $m_courses = getAllSubjets();
}else{
  $m_courses = getAllSubjectsByRootUABCategory();
  $m_categories = getAllCategoriesFromRootCategory();
}


if($uabCourseId != NULL){
  if($_GET['id'] != NULL || $reload != NULL){
    //EDITAR
    if($reload != NULL){
      $rootCategory = $_GET['rootcategory'];
    }else{
      $rootCategory = getRootCategory($_GET['id']);
    }
   
    if ($rootCategory != NULL) {
      $subs = getAllSubjectsByCategory($rootCategory);
      $m_courses = array();
      foreach ($subs as $key => $value) {
        $subject = new stdClass();
        $subject->id = $key;
        $subject->fullname = $value;
        $m_courses[] = $subject;
      }
    }  
    $m_courses_selected = getAllSubjectsFromUABCourse($uabCourseId);
    $subjects_array = array();
    foreach ($m_courses_selected as $item) {
      $subjects_array[] = $item->subject_id;
    }
  }else{
    //SALVAR
    $p_subjects = $_GET['subjects'];
    $uabCourseName = $_GET['uabCourseName'];
    $rootCategory = $_GET['rootcategory'];
    if ($rootCategory != NULL) {
      $subs = getAllSubjectsByCategory($rootCategory);
      $m_courses = array();
      foreach ($subs as $key => $value) {
        $subject = new stdClass();
        $subject->id = $key;
        $subject->fullname = $value;
        $m_courses[] = $subject;
      }
    }
    //Adiciona o curso UAB
    $data_uab_course = [
        uab_id         => $uabCourseId,
        name           => $uabCourseName,
        root_category  => $rootCategory,
        last_send      => 0
    ];
    //CHECAR SE JÁ EXISTE
    if(!local_get_record($table_course, $field1="uab_id", $value1=$uabCourseId))
      local_insert_record($table_course, $data_uab_course);

    //Adiciona os Subjects
    $subjects_array = explode(',',$p_subjects);
    //limpa opções anteriores
    local_delete_records($table_subject, $field1="uab_id", $value1=$uabCourseId);
    foreach ($subjects_array as $subject_id) {
      $data_uab_course_subject = [
        uab_id     => $uabCourseId,
        subject_id => $subject_id,
        last_send  => 0
      ];
      local_insert_record($table_subject, $data_uab_course_subject);
    }
    $isSaved = true;
  }
}else{
  
}

?>


<script type="text/javascript" src="./js/jquery.min.js?v=3.4.1"></script>
<script type="text/javascript" src="./js/jquery.transfer.js?v=0.0.6"></script>


<div class="uab_course_form">
<div id="uab_result" class="uab_result"> <?php echo $isSaved ? '<span id="uabSuccess" style="color: green;"><b>Curso UAB salvo com sucesso!</b></span>' : ""; ?> </div>
<h2>Fomulário UAB Course</h2>

<form id="uab_form_id" name="uab_form">
<label for="uabcourse">Escolha o Curso UAB:</label>

<select name="uabid" id="select_uabcourse">
<?php
  echo "<option disabled selected value> -- Selecione uma opção -- </option>";
  foreach ($course as $c) {
    if ($c['uabid'] == $uabCourseId){
      echo "<option value=\"{$c['uabid']}\" selected>{$c['nome']}</option>";
    }else{
      echo "<option value=\"{$c['uabid']}\">{$c['nome']}</option>";
    }
  }
?>
</select>
<br/>
<br/>
<label for="uabrootcategory">Escolha a categoria raiz do curso:</label>
<select name="rootcategory" id="select_rootcategory" onchange="loadSubjects()">
<?php
  echo "<option disabled selected value> -- Selecione uma opção -- </option>";
  foreach ($m_categories as $key => $m_category) {
    if ($key == $rootCategory){
      echo "<option value=\"{$key}\" selected>{$m_category}</option>";
    }else{
      echo "<option value=\"{$key}\">{$m_category}</option>";
    }
  }
  
  // foreach ($categories as $category) {
  //   echo $category->id] = $category->name;
  // }
    
?>
</select>
<br/>
<br/>
<label for="uabsubjects">Escolha as disciplinas do Curso UAB:</label>

  <div>
      <div id="moodlecourses" class="moodlecourses-box"></div>
  </div>
  <input id="form_uabCourseName" type="hidden" name="uabCourseName" value="">
  <input id="form_subjects" type="hidden" name="subjects" value="">
  <input id="uabcourse_submit" type="submit" class="form-submit" value="Salvar">
</form>
</div>
  <script type="text/javascript">
    
    

    var dataArray1 = [
        <?php 
          $size = count($m_courses);
          for ($i=0; $i < $size; $i++) {          
                  echo  "{"; 
                  echo     "\"uabid\": {$m_courses[$i]->id},";  
                  echo     "\"nome\": '{$m_courses[$i]->fullname}',";
                  for ($j=0; $j < count($subjects_array); $j++) { 
                    if($subjects_array[$j] == $m_courses[$i]->id){
                      echo "\"selected\": true";
                    }
                  }
                  echo  "},"; 
          }        
        ?>
    ];

    var settings1 = {
        "dataArray": dataArray1,
        "itemName": "nome",
        "valueName": "uabid",
        "callable": function (items) {
            console.dir(items)
        }
    };

    var myTransfer = $("#moodlecourses").transfer(settings1);
    
    $("form").submit(function(e){
        //Pega os cursos selecionados e coloca-os separados por vírgula
        var uabCourseSelectValue = $("#select_uabcourse option:selected").val();
        var mCoursesSelected = myTransfer.getSelectedItems();
        var mCoursesArray = [];
        if (mCoursesSelected.length == 0 || uabCourseSelectValue == '' ){
          alert("Preencha todo o formulário antes de salvar!");
          e.preventDefault(e);
        }else{
          for (let index = 0; index < mCoursesSelected.length; index++) {   
            var element = mCoursesSelected[index];
            mCoursesArray[index] = element.uabid;
          }
          var mCourses = mCoursesArray.join(',');

          //Pega o valor selecionado do Select
          //var uabCourse = $("#select_uabcourse").val();
          var uabCourseName = $("#select_uabcourse option:selected").text();
          $("#form_uabCourseName").val(uabCourseName);
          $("#form_subjects").val(mCourses);
          $("#uab_form_id").submit();
        }      
    });

    function loadSubjects(){
      var uabCourseName = $("#select_uabcourse").val();
      var uabRootCategory = $("#select_rootcategory").val();
      window.location = location.protocol + '//' + location.host + location.pathname+"?rootcategory="+uabRootCategory+"&uabid="+uabCourseName+"&reload=1";
    } 
    
</script>

<?php echo $OUTPUT->footer(); ?>
