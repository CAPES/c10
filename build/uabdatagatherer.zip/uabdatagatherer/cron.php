<?php
/**
 * cron.php - Cronjob for the UAB Data Gatherer
 *
 * The data from the courses are gathered and stored in itens. The itens are
 * grouped in baskets, each basket represents a course. After all baskets are
 * ready the process informs the uabdatagatherer server to gather the data.
 *
 * @author Francisco Neto
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package uabdatagatherer
 * @param int id The course's id to get the basket from.
 */
require_once('../../config.php');
require_once('locallib.php');
require_once('window_execution.php');
require_once('request.php');

global $CFG;
session_write_close();


if (isset($_SERVER['REMOTE_ADDR'])) { // Script accessed via the web.
	//get array from url query
	$queryArray = queryToArray($_SERVER['QUERY_STRING']);
	//check required datetime

	if (!isset($queryArray['from_datetime'])) {
		$msg = " Erro: from datetime is required.";
		echo $msg;
		exit;
	}
	
	//check if datetime is a valid timestamp
	if (!isValidTimeStamp($queryArray['from_datetime'])) {
		$msg = " Erro: from datetime is not valid.";
		echo $msg;
		exit;
	}

	if (!isset($queryArray['until_datetime'])) {
		$msg = " Erro: until datetime is required.";
		echo $msg;
		exit;
	}
	
	//check if datetime is a valid timestamp
	if (!isValidTimeStamp($queryArray['until_datetime'])) {
		$msg = " Erro: until datetime is not valid.";
		echo $msg;
		exit;
	}

	set_time_limit(0);
	$web = true;
	// Disable caching
	header("Expires: Fri, 01 Jan 2016 00:00:00 GMT");
	header("Cache-Control: max-age=0, no-cache, must-revalidate, proxy-revalidate");
	// Force txt
	header("Content-Type: text/plain");
} else { // Script called via cron
	$web = false;
}

//Verify if server URL is configured
$serverURL = get_config("block_uabdatagatherer","ServerURL");
if ($serverURL == "") {
	removeCronjobFile();
	$msg = " Erro: ServerURL not configured.";
	if ($web) {
		echo $msg;
		exit;
	} else {
		mtrace($msg);
		return false;
	}
}

// Verify if IES is configured
$iesid = get_config("block_uabdatagatherer","IES");
if ($iesid == 0) {
	removeCronjobFile();
	$msg = " Error: IES not configured.";
	if ($web) {
		echo $msg;
		exit;
	} else {
		mtrace($msg);
		return false;
	}
}

// Verify if uabkey is configured
$uabkey = get_config("block_uabdatagatherer","Key");
if ($uabkey == "") {
	removeCronjobFile();
	$msg = " Error: Verify if server ($serverURL) is ok";
	if ($web) {
		echo $msg;
		exit;
	} else {
		mtrace($msg);
		return false;
	}
}
else if (!isset($queryArray['server_key']) || $queryArray['server_key'] != $uabkey) {
	$msg = " Erro: invalid key.";
	echo $msg;
	exit;
}


// Get variables to control the execution time
$hour = get_config("block_uabdatagatherer","StartHour");
$minute  = get_config("block_uabdatagatherer","StartMinute");
$maxruntime = get_config("block_uabdatagatherer","MaxRuntime");

$a_today = explode(',',date("Y,m,d,"));
$timestart = make_timestamp($a_today[0], $a_today[1], $a_today[2], $hour, $minute);
if ( ($hour+$maxruntime) < 24) {
	$timefinish = make_timestamp($a_today[0], $a_today[1], $a_today[2], $hour+$maxruntime, $minute);
} else {
	$timefinish = make_timestamp($a_today[0], $a_today[1], $a_today[2] +1, $hour+$maxruntime-24, $minute);
}

//When testing uncomment the next 2 lines
//$timestart = usertime(time())-1;
//$timefinish =usertime(time()) + DAYSECS;

// mtrace("timestart: {$timestart} timefinish {$timefinish} now {$now}");
//check windown execution
$window_execution = new window_execution();
$msg = $window_execution->isInWindow($timestart, $timefinish);
if ($msg !== true){
	
	$request = new Request();
	$isExist = $request->getQueuedOrStartedByFromDateTime($queryArray['from_datetime'], $queryArray['until_datetime']);
	
	if($isExist == null) {
		$request->createQueued($queryArray['from_datetime'], $queryArray['until_datetime']);
		$msg = $msg." . Request added to our queue.";
	}
	else{
		$msg = $msg." But your datetime is already ".$isExist[0]->status. ".";
	}
	
	if ($web) {
		// We returns the timestamp when the process can start
		echo $msg;
		exit;
	} else {
		mtrace($msg);
		return true;
	}
}

// Get a array of items filenames
if (! ($dirhandle = opendir("{$CFG->dirroot}/blocks/uabdatagatherer/items"))) {
	removeCronjobFile();
	$msg = " Error: Directory items not found!!";
	if ($web) {
		echo $msg;
		exit();
	} else {
		mtrace($msg);
		return false;
	}
}

global $CFG;
while (false !== ($filename = readdir($dirhandle))) {
	if (preg_match("/item_(.+)\.php/", $filename, $classname)) {
		require_once("{$CFG->dirroot}/blocks/uabdatagatherer/items/".$filename);
		$itemclass[]=$classname[1];
	}
}

// Get list of courses configured
if (! $courses = array_values(getAllCoursesConfigured()) ) {
	$msg = " Error: Courses not configured.";
	if ($web) {
		echo $msg;
		exit;
	} else {
		mtrace($msg);
		return false;
	}
}
$inited = createOrLoadJsonObject($queryArray['from_datetime'], $queryArray['until_datetime'], $iesid, $courses);
if ($inited === false) {
	$msg = " Error: Cannot load a file.";
	if ($web) {
		echo $msg;
		exit;
	} else {
		mtrace($msg);
		return false;
	}
}
# Process courses's data
for ($array_index = 0; $array_index < count($courses); $array_index++) {	
	$course = $courses[$array_index];
		
	if ($course->status == 'queued') {
		
		$subjects = array_values(getAllSubjectsFromUABCourse($course->uab_id));

		$CFG->uabdata['courses'][$array_index]['number_of_subjects'] = count($subjects);
		
		for ($subject_index = 0; $subject_index < count($subjects); $subject_index++) {

			$subject = $subjects[$subject_index];
		
			if ($subject->status == 'queued') {			
				$CFG->uabdata['courses'][$array_index]['subjects'][$subject_index] = [
					"subject_name" => $subject->fullname,
					"subject_id" => $subject->subject_id
				];
				setUsersByCourseId($subject->subject_id, $array_index, $subject_index);

				//add new itens here temporarily 
				$new_itens = [
					0 => "t_assign",
					1 => "n_access",
					2 => "t_grade",
					3 => "n_forum",
					4 => "n_message",
					5 => "n_resource"
				];	


				// Process all other items
				foreach ($new_itens as $iclass) {
					$classname = "uabdatagatherer_item_".$iclass;
					error_log(print_r("NOTICE: *ITEM: ".$iclass." *Subject: ".$subject->fullname, TRUE));
					$item = new $classname($subject->subject_id, $array_index, $subject_index, $CFG->uabdata['courses'][$array_index]['subjects'][$subject_index]['users'] );	
					unset($item);
				}
				//change subject status to processed
				$data = [
					"id" => $subject->id,
					"status" => "processed"
				];
				local_update_record("block_uabdatagatherer_subjec", $data);
				$msg = $window_execution->isInWindow(usertime(time()), $timefinish);
				// Check if we still have time to continue	
				if ($msg !== true) {
					//save file					
					if(saveJsonFile()){
						$msg = "Process not finished. Will be continued at the next window execution. ".$msg;						
					}
					else{
						$msg = "Error: cannot save started file";
					}
					if ($web) {
						echo $msg;
						exit;
					} else {
						mtrace($msg);
						return true;
					}
				}
			}
		}
	}	
	//change course status to processed
	$data = [
		"id" => $course->id,
		"status" => "processed"
	];
	local_update_record("block_uabdatagatherer_course", $data);
	$msg = $window_execution->isInWindow(usertime(time()), $timefinish);
	// Check if we still have time to continue	
	if ($msg !== true) {
		//salvar arquivo
		if(saveJsonFile()){
			$msg = "Process not finished. Will be continued at the next window execution. ".$msg;					
		}
		else{
			$msg = "Error: cannot save started file";
		}
		if ($web) {
			echo $msg;
			exit;
		} else {
			mtrace($msg);
			return true;
		}
	}
}
//

downloadJson();

if ($web) {
	exit;
} else {
	return true;
}
# Queue course's data (make zip files)
foreach ($courses as $course) {
	if ($course->status == 2) { // status == 2 ==> course processed, need to be queued
		if (make_course_log_file($course->courseid) && make_course_basket_file ($course->courseid)) {
			$course->status = 3; // set course to queued
			$course->timemodified = time();
			local_update_record("block_uabdatagatherer",$course);
			//mtrace ("Queued course log OK");
		} else {
			removeCronjobFile();
			$msg = "Error while creating course_log and course_basket files to courseid {$course->courseid}.";
			if ($web) {
				echo $msg;
				exit;
			} else {
				mtrace($msg);
				return false;
			}
		}
	}
	// Check if we still have time to continue
	if (usertime(time()) > $timefinish) {
		removeCronjobFile();
		$msg = " Process not finished will continue next time.";
		if ($web) {
			echo $msg;
			exit;
		} else {
			mtrace($msg);
			return true;
		}
	}
}

# Sync course's data
foreach ($courses as $course) {
	if ($course->status == 3) { // status == 3 ==> course queued, need to be synced
		$statusmsg=getUrlContent($serverURL."?uabkey={$uabkey}&id={$course->courseid}");
		//echo $serverURL."?uabkey={$uabkey}&id={$course->courseid}"; die();
		if ($statusmsg == "OK") {
			$course->status = 4; // set course to synced
			$course->timemodified = time();
			local_update_record("block_uabdatagatherer",$course);
			//mtrace ("Sync course log OK");
		} else {
			removeCronjobFile();
			$msg = "Error while syncing course_log and course_basket files to courseid {$course->courseid}: {$statusmsg}.";
			if ($web) {
				echo $msg;
				exit;
			} else {
				mtrace();
				return false;
			}
		}
	}
	// Check if we still have time to continue
	if (usertime(time()) > $timefinish) {
		removeCronjobFile();
		$msg = " Process not finished will continue next time.";
		if ($web) {
			echo $msg;
			exit;
		} else {
			mtrace($msg);
			return true;
		}
	}
}

# Delete files from course synced
foreach ($courses as $course) {
	if ($course->status == 4) { // status == 4 ==> course synced, need to be cleaned
		$data_dir=make_upload_directory('uabdata' . '/' . $course->courseid);
		$zip_file_log = $data_dir .'/course_log.zip';
		if(file_exists($zip_file_log)){
			if (! unlink($zip_file_log)) {
				$msg = "Error while cleaning course_log zip file from courseid {$course->courseid}.";
				if ($web) {
					echo $msg;
				} else {
					mtrace($msg);
				}
			}
		}
		$zip_file_basket = $data_dir .'/course_basket.zip';
		if(file_exists($zip_file_basket)){
			if (! unlink($zip_file_basket)) {
				$msg = "Error while cleaning course_basket zip file from courseid {$course->courseid}.";
				if ($web) {
					echo $msg;
				} else {
					mtrace($msg);
				}
			}
		}
		if ( (! file_exists($zip_file_log)) && (! file_exists($zip_file_basket)) ) {
			$course->status = 5; // set course to cleaned
			$course->timemodified = time();
			local_update_record("block_uabdatagatherer",$course);
		}
	}
	// Check if we still have time to continue
	if (usertime(time()) > $timefinish) {
		removeCronjobFile();
		$msg = " Process not finished will continue next time.";
		if ($web) {
			echo $msg;
			exit;
		} else {
			mtrace($msg);
			return true;
		}
	}
}
removeCronjobFile();
$msg = " all done.";
if ($web) {
	echo $msg;
} else {
	mtrace($msg);
}