<?php
/**
 * version.php - uabdatagatherer version file
 *
 * @author Francisco Neto
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package uabdatagatherer
 */
require_once('locallib.php');

$plugin->component = 'block_uabdatagatherer';  // Recommended since 2.0.2 (MDL-26035). Required since 3.0 (MDL-48494)
$plugin->version   = 2020115000;  // YYYYMMDDHH (year, month, day, 24-hr time)
switch (MOODLE_DETECTED_VERSION) {
	case 19: // Moodle 1.9
		$plugin->requires  = 2007101591 ; // YYYYMMDDHH (This is the release version for Moodle 1.9)
		break;
	default: // After 1.9 we need to change the requires because Moodle 2.0 gives error
		$plugin->requires  = 2010112400 ; // YYYYMMDDHH (This is the release version for Moodle 2.0)
		break;
}
$plugin->cron      = 3600; // 1 hour
//$plugin->cron      = 15; // 15s
$plugin->maturity  = MATURITY_ALPHA;
$plugin->release   = '0';