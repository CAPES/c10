<?php
/**
 * settings.php - Settings configuration to the plugin uabdatagatherer.
 *
 * @author Francisco Neto
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package uabdatagatherer
 */

global $CFG;
require_once ("{$CFG->dirroot}/blocks/uabdatagatherer/locallib.php");

$settings->add(new admin_setting_heading(
            'headerconfig',
            get_string('headerconfig', 'block_uabdatagatherer'),
            get_string('descconfig', 'block_uabdatagatherer')
        ));

$settings->add(new admin_setting_configtext(
		'block_uabdatagatherer/ServerURL',
		get_string('labelserverurl', 'block_uabdatagatherer'),
		get_string('descserverurl', 'block_uabdatagatherer'),
		''
		));

$settings->add(new admin_setting_configtext(
		'block_uabdatagatherer/Key',
		get_string('labelkey', 'block_uabdatagatherer'),
		get_string('desckey', 'block_uabdatagatherer'),
		''
		));

/*
$ies = local_get_records("block_uabdatagatherer_ies");
$a_ies[0] = " Nenhuma selecionada";
foreach ($ies as $i) {
	$a_ies[$i->uabid]= $i->sigla . "&emsp;&emsp;|&emsp;" . $i->nome;
}
*/

require ("{$CFG->dirroot}/blocks/uabdatagatherer/array/ies.php");

$a_ies[0] = " Nenhuma selecionada";
foreach ($ies as $i) {
	$a_ies[$i["uabid"]]= $i["sigla"] . "&emsp;&emsp;|&emsp;" . $i["nome"];
}
asort($a_ies);
$settings->add(new admin_setting_configselect(
		'block_uabdatagatherer/IES',
		'IES',//get_string('labelmaxruntime', 'block_uabdatagatherer'),
		'IES usuária do Moodle',//get_string('descmaxruntime', 'block_uabdatagatherer'),
		0,
		$a_ies
		));

$settings->add(new admin_setting_configtime(
		'block_uabdatagatherer/StartHour',
		'StartMinute',
		get_string('labelruntimestart', 'block_uabdatagatherer'),
		get_string('descruntimestart', 'block_uabdatagatherer'),
		array('h' => 0, 'm' => 0)
		));

$settings->add(new admin_setting_configselect(
		'block_uabdatagatherer/MaxRuntime',
		get_string('labelmaxruntime', 'block_uabdatagatherer'),
		get_string('descmaxruntime', 'block_uabdatagatherer'),
		0,
		array(	1 => '1 '.get_string('hour'),
				2 => '2 '.get_string('hours'),
				3 => '3 '.get_string('hours'),
				4 => '4 '.get_string('hours'),
				5 => '5 '.get_string('hours'),
				6 => '6 '.get_string('hours'),
				7 => '7 '.get_string('hours'),
				8 => '8 '.get_string('hours') )
				));


if (!$options = local_get_records("role")) {
	$options = array();
}
/*

$options2 = array();
foreach ($options as $option) {
	$options2[$option->id] = $option->name;
}
require_once ("{$CFG->dirroot}/lib/accesslib.php");
//$context=get_context_instance($contextlevel,);
//$context=get_system_context();
//$teste=role_fix_names(get_all_roles(), null, ROLENAME_ALIAS);
$teste=get_all_roles();
*/
//echo "{$CFG->release} = ".MOODLE_DETECTED_VERSION; die();
switch (MOODLE_DETECTED_VERSION) {
	case 19: // Moodle 1.9
	case 20: // Moodle 2.0
		if (!$options = local_get_records("role")) {
			$options = array();
		}
		$options2 = array();
		foreach ($options as $option) {
			$options2[$option->id] = $option->name;
		}
		break;
	default:
		$options=role_fix_names(get_all_roles(), null, ROLENAME_ALIAS);
		$options2 = array();
		foreach ($options as $option) {
			$options2[$option->id] = $option->localname;
		}
		break;
}

//STUDENT
$settings->add(new admin_setting_configmultiselect(
		'block_uabdatagatherer/StudentRoles',
		get_string('labelstudentroles', 'block_uabdatagatherer'),
		get_string('descstudentroles', 'block_uabdatagatherer'),
		array(5),
		$options2));

//TUTOR EAD
$settings->add(new admin_setting_configmultiselect(
	'block_uabdatagatherer/TutorEADRoles',
	get_string('labeltutoreadroles', 'block_uabdatagatherer'),
	get_string('desctutoreadroles', 'block_uabdatagatherer'),
	0,
	$options2));

//PROFESSOR FORMADOR
$settings->add(new admin_setting_configmultiselect(
	'block_uabdatagatherer/TeacherFormerRoles',
	get_string('labelteacherformerroles', 'block_uabdatagatherer'),
	get_string('descteacherformerroles', 'block_uabdatagatherer'),
	0,
	$options2));

//TUTOR PRESENCIAL
$settings->add(new admin_setting_configmultiselect(
	'block_uabdatagatherer/TutorPresentialRoles',
	get_string('labeltutorpresentialroles', 'block_uabdatagatherer'),
	get_string('desctutorpresentialroles', 'block_uabdatagatherer'),
	0,
	$options2));




//PROFESSOR CONTEUDISTA
$settings->add(new admin_setting_configmultiselect(
	'block_uabdatagatherer/TeacherContentist',
	get_string('labelteachercontentistroles', 'block_uabdatagatherer'),
	get_string('descteachercontentistroles', 'block_uabdatagatherer'),
	0,
	$options2));


$categories = getAllCategoriesNonLeaf();
foreach ($categories as $category) {
	$options3[$category->id] = $category->name;
}

//Cursos UAB
$settings->add(new admin_setting_configmultiselect(
	'block_uabdatagatherer/RootUABCourses',
	get_string('labelrootuabcourses', 'block_uabdatagatherer'),
	get_string('descrootuabcourses', 'block_uabdatagatherer'),
	0,
	$options3));


//LINK PARA CONFIGURAÇÃO DOS CURSOS UAB
$link ='<a href="'.$CFG->wwwroot.'/blocks/uabdatagatherer/uabcourses_config.php">'.get_string('configUabLink', 'block_uabdatagatherer').'</a>';
$settings->add(new admin_setting_heading('block_uabdatagatherer/ConfigUabLink', '', $link));