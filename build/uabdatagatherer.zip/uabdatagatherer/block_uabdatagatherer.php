<?php
/**
 * block_uabdatagatherer.php - uabdatagatherer class
 *
 * @author Francisco Neto
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package uabdatagatherer
 */

defined('MOODLE_INTERNAL') || die();
global $CFG;
require_once ("{$CFG->dirroot}/blocks/uabdatagatherer/locallib.php");

class block_uabdatagatherer extends block_base {
	function init() {
    	$this->title   = get_string('title', 'block_uabdatagatherer');
		//if (preg_match("/^1\.9*/", $CFG->release)) { //Hack to work in Moodle 1.9
		if (MOODLE_DETECTED_VERSION == 19) { //Hack to work in Moodle 1.9
			$plugin = new stdClass();
			if (! defined('MATURITY_ALPHA')) {
				define('MATURITY_ALPHA',"MATURITY_ALPHA");
			}
			global $CFG;
			require "{$CFG->dirroot}/blocks/uabdatagatherer/version.php";
    		$this->version = $plugin->version;
    		$this->cron = $plugin->cron;
		}
	}

	function get_content() {
    	if ($this->content !== NULL) {
      		return $this->content;
    	}

    	global $CFG, $COURSE;

    	$this->content         =  new stdClass;
    	$this->content->text = '';

		/*/ Only show content if course's data is in the open status
		//$edg = new uabdatagatherer_course($COURSE->id);
    	$edg = local_get_record("block_uabdatagatherer", "courseid", $COURSE->id);
    	if (!isset($edg->status) || ($edg->status == 0) ) {
    		$this->content->text = "<a href=".$CFG->wwwroot."/blocks/". $this->name() ."/set_student_status.php?id={$COURSE->id}>".
    	                         get_string('update_course', 'block_uabdatagatherer')."</a>";
    	}//*/
    	$this->content->text = "<a href=".$CFG->wwwroot."/blocks/uabdatagatherer/manager_setstatus.php>".
    			get_string('update_course', 'block_uabdatagatherer')."</a>";
    	$this->content->footer = '';

    	return $this->content;
	}

	function has_config() {
		return true;
	}

	/**
	 * Implement the uabdatagatherer cron job.
	 *
	 * @author Francisco Neto
	 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
	 * @package uabdatagatherer
	 */
	function cron() {
		require_once('cron.php');
		return true;
	}//*/

	/* Comentada
	function applicable_formats() {
		return array(
				'course-view' => true);
	}*/

	/**
	 * Returns true or false, depending on whether this block has any content to display
	 * and whether the user has permission the permission block/uabdatagatherer:respond
	 *
	 * @return boolean
	 */
	function is_empty() {
		$context = get_context_instance(CONTEXT_BLOCK, $this->instance->id);
		if ( !has_capability('block/uabdatagatherer:respond', $context) ) {
			return true;
		}
		$this->get_content();
		return(empty($this->content->text) && empty($this->content->footer));
	}

	/**
	 * Function to do some cleanup before this block be deleted.
	 */
	function before_delete() {
		$data_dir=make_upload_directory('uabdata');
		rrmdir($data_dir);
	}
}