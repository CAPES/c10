<?php  //$Id$

// This file keeps track of upgrades to
// the uabdatagatherer module
//
// Sometimes, changes between versions involve
// alterations to database structures and other
// major things that may break installations.
//
// The upgrade function in this file will attempt
// to perform all the necessary actions to upgrade
// your older installtion to the current version.
//
// If there's something it cannot do itself, it
// will tell you what you need to do.
//
// The commands in here will all be database-neutral,
// using the functions defined in lib/ddllib.php

function xmldb_block_uabdatagatherer_upgrade($oldversion=0) {

    global $CFG, $THEME, $DB;
    $dbman = $DB->get_manager();
    $result = true;

/// And upgrade begins here. For each one, you'll need one
/// block of code similar to the next one. Please, delete
/// this comment lines once this file start handling proper
/// upgrade code.

/// if ($result && $oldversion < YYYYMMDD00) { //New version in version.php
///     $result = result of "/lib/ddllib.php" function calls
/// }

/// Lines below (this included)  MUST BE DELETED once you get the first version
/// of your module ready to be installed. They are here only
/// for demonstrative purposes and to show how the uabdatagatherer
/// iself has been upgraded.

/// For each upgrade block, the file uabdatagatherer/version.php
/// needs to be updated . Such change allows Moodle to know
/// that this file has to be processed.

/// To know more about how to write correct DB upgrade scripts it's
/// highly recommended to read information available at:
///   http://docs.moodle.org/en/Development:XMLDB_Documentation
/// and to play with the XMLDB Editor (in the admin menu) and its
/// PHP generation posibilities.
    if ($result && $oldversion < 2020062302) {
        // Define table block_uabdatagatherer_cours to be created.
        $table = new xmldb_table('block_uabdatagatherer_course');

        // Adding fields to table block_uabdatagatherer_cours.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('uab_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('name', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, null);
        $table->add_field('last_send', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');

        // Adding keys to table block_uabdatagatherer_cours.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id', 'uab_id'));

        // Conditionally launch create table for block_uabdatagatherer_cours.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }


        // Define table block_uabdatagatherer_subj to be created.
        $table = new xmldb_table('block_uabdatagatherer_subjec');

        // Adding fields to table block_uabdatagatherer_subj.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('uab_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('subject_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('last_send', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');

        // Adding keys to table block_uabdatagatherer_subj.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
        $table->add_key('foreign1', XMLDB_KEY_FOREIGN, array('uab_id'), 'block_uabdatagatherer_course', array('uab_id'));
        $table->add_key('foreign2', XMLDB_KEY_FOREIGN, array('subject_id'), 'course', array('id'));

        // Conditionally launch create table for block_uabdatagatherer_subj.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // // Uabdatagatherer savepoint reached.
        // upgrade_mod_savepoint(true, 2020062300, 'uabdatagatherer');

    }

    if ($oldversion < 2020062900) {

        // Define key unique (unique) to be added to block_uabdatagatherer_course.
        $table = new xmldb_table('block_uabdatagatherer_course');
        $key = new xmldb_key('unique', XMLDB_KEY_UNIQUE, array('uab_id'));

        // Launch add key unique.
        $dbman->add_key($table, $key);
    }

    if ($oldversion < 2020082000) {

            // Define table block_uabdatagatherer_rquest to be created.
        $table = new xmldb_table('block_uabdatagatherer_rquest');

        // Adding fields to table block_uabdatagatherer_rquest.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('from_datetime', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('status', XMLDB_TYPE_CHAR, '255', null, null, null, null);
        $table->add_field('created_at', XMLDB_TYPE_INTEGER, '10', null, null, null, null);

        // Adding keys to table block_uabdatagatherer_rquest.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));

        // Conditionally launch create table for block_uabdatagatherer_rquest.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }
    }

    if ($oldversion < 2020082400) {

        // Define field status to be added to block_uabdatagatherer_course.
        $table = new xmldb_table('block_uabdatagatherer_course');
        $field = new xmldb_field('status', XMLDB_TYPE_CHAR, '255', null, null, null, null, 'last_send');

        // Conditionally launch add field status.
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

    }

    if ($oldversion < 2020102800) {

        // Define field until_datetime to be added to block_uabdatagatherer_rquest.
        $table = new xmldb_table('block_uabdatagatherer_rquest');
        $field = new xmldb_field('until_datetime', XMLDB_TYPE_INTEGER, '10', null, null, null, null, 'created_at');

        // Conditionally launch add field until_datetime.
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

    }
    
    if ($oldversion < 2020115000) {

        // Define field status to be added to block_uabdatagatherer_course.
        $table = new xmldb_table('block_uabdatagatherer_subjec');
        $field = new xmldb_field('status', XMLDB_TYPE_CHAR, '255', null, null, null, null, 'subject_id');

        // Conditionally launch add field status.
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

    }


/// Lines above (this included) MUST BE DELETED once you get the first version of
/// yout module working. Each time you need to modify something in the module (DB
/// related, you'll raise the version and add one upgrade block here.

/// Final return of upgrade result (true/false) to Moodle. Must be
/// always the last line in the script
    return $result;
}

?>
