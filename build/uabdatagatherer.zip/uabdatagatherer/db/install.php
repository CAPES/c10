<?php


    
defined('MOODLE_INTERNAL') || exit(0);

function xmldb_block_uabdatagatherer_install(){
    global $CFG;
    global $DB;


    // Get system context.
    //$context = context_system::instance();
    // adicionando a categoria 
    $dataprofilecategory = new stdClass();
    $dataprofilecategory->name = "Dados para CAPES/UAB";
    $dataprofilecategory->sortorder = 1;
    $category_id = $DB->insert_record("user_info_category", $dataprofilecategory, $returnid=true, $bulk=false);

    // adicionando o campo CPF
    $dataobject = new stdClass();
    $dataobject->shortname = "CPF";
    $dataobject->name = "CPF";
    $dataobject->datatype = "text";
    $dataobject->description = "Campo para preencher com o valor do número do CPF usando apenas números. Exemplo:12345678900";
    $dataobject->descriptionformat = 1;
    $dataobject->categoryid = $category_id;
    $dataobject->sortorder = 1;
    $dataobject->required = 1;
    $dataobject->locked = 0;
    $dataobject->visible = 2;
    $dataobject->forceunique = 1;
    $dataobject->signup = 1;
    //$dataobject->defaultdata = "12345678900";
    $dataobject->defaultdataformat = 0;
    $dataobject->param1 = 30;
    $dataobject->param2 = 2048;
    $dataobject->param3 = 0;
    //$dataobject->param4 = 0;
    //$dataobject->param5 = 0;
    $is_cpf_added = $DB->insert_record("user_info_field", $dataobject, $returnid=true, $bulk=false);
    //return(true);
    }
?>