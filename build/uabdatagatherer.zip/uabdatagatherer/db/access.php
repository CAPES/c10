<?php
/**
 * access.php - Capabilities for plugin uabdatagatherer
 *
 * @author Francisco Neto
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package uabdatagatherer
 */

$capabilities = array(
		'block/uabdatagatherer:respond' => array(
				'riskbitmask' => RISK_PERSONAL,
				'captype' => 'write',
				'contextlevel' => CONTEXT_BLOCK,
				'legacy' => array(
						'teacher' => CAP_ALLOW,
						'editingteacher' => CAP_ALLOW,
						'admin' => CAP_ALLOW
					),
				'archetypes' => array(
						'teacher' => CAP_ALLOW,
						'editingteacher' => CAP_ALLOW,
						'manager' => CAP_ALLOW
					)
				),
				'block/uabdatagatherer:config' => array(
					'riskbitmask' => RISK_PERSONAL,
					'captype' => 'write',
					'contextlevel' => CONTEXT_BLOCK,
					'legacy' => array(							
							'admin' => CAP_ALLOW
						),
					'archetypes' => array(							
							'manager' => CAP_ALLOW
						)
			)
);

// Hack to work in Moodle 1.9
global $CFG;
require_once ("{$CFG->dirroot}/blocks/uabdatagatherer/locallib.php");
if (MOODLE_DETECTED_VERSION == 19) {
	$block_uabdatagatherer_capabilities = $capabilities;
}