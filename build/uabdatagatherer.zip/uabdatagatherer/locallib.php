<?php
/**
 * localib.php - uabdatagatherer local classes and functions
 *
 * @author Francisco Neto
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package uabdatagatherer
 */

defined('MOODLE_INTERNAL') || die();


// Define moodle version
global $CFG;
require_once ("{$CFG->dirroot}/blocks/uabdatagatherer/request.php");

if (preg_match("/^1\.9.*/", $CFG->release)) {
	define('MOODLE_DETECTED_VERSION','19');
} elseif  (preg_match("/^2\.0.*/", $CFG->release)) {
	define('MOODLE_DETECTED_VERSION','20');
} else if  (preg_match("/^2\.5.*/", $CFG->release)) {
	define('MOODLE_DETECTED_VERSION','25');
} else {
	define('MOODLE_DETECTED_VERSION','999');
}

/**
 * Represents a course's data.
 *
 * The course's data includes a students list and his status.
 *
 * @author Francisco Neto
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package uabdatagatherer
 */
class uabdatagatherer_course {
	var $id=0;
	var $courseid=0;
	var $grandearea = 99900000;
	var $status=0;
	var $timestamp_last=0;
	var $timestamp_last_send=0;
	var $timemodified=0;
	var $student_status;
	//var $recent;

	/**
	 * Create a new instance of uabdatagatherer_course.
	 *
	 * Load from database or calculate some defaults and create a new record in the database
	 *
	 * @param int $courseid The course's ID from where the data will be gathered.
	 * @return NULL
	 */
	function uabdatagatherer_course($courseid="") {
		if (empty($courseid)) return NULL;

		$this->courseid = $courseid;
		if (! $this->exists()) { // course not in table
			$this->status = 0;
			//$this->polouab = 0;
			$this->grandearea = 0;
			$this->timestamp_last = $this->estimate_course_completation_date($courseid);
			$this->timestamp_last_send = 0;
			$this->timemodified = time();
			$this->student_status = $this->get_student_status_list();
			//$this->recent = true;
			//$this->save_or_update();
		} else {
			//$this->recent = false;
			$this->load();
			if ($this->status == 0) { // If status is 0 we could check if there is new students or removed students from the course
				$new_student_status = $this->get_student_status_list();
				
				foreach ($new_student_status as $new) {
					foreach ($this->student_status as $old) {
						if ($new->userid == $old->userid) {
							$new->id = $old->id;
							$new->status = $old->status;
							$new->polouab = $old->polouab;
							continue;
						}
					}
				}
			}
		}
	}

	/**
	 * Get a array of students and his status.
	 *
	 * @return array Where key is the $userid and the value is the student's status
	 */
	function get_student_status_list() {
		global $CFG;
		require_once("{$CFG->libdir}/gradelib.php");
		require_once("{$CFG->dirroot}/grade/querylib.php");

		$userids = $this->get_students_ids();
		$grade = grade_get_course_grades($this->courseid, $userids);
		$user_grades = $grade->grades;

		$edg_stusta = array();
		foreach ($userids as $userid) {
			$stusta = new stdClass();
			$stusta->userid = $userid;
			$stusta->courseid = $this->courseid;
			if ($user_grades[$userid]->grade >= $grade->gradepass ) {
				$stusta->status = 1;
			} else {
				$stusta->status = 2;
			}
			$stusta->timemodified = time();
			//$stusta->grade = round($user_grades[$userid]->grade,2) ."/". round($grade->grademax,2);
			$stu_grade = round($user_grades[$userid]->grade / $grade->grademax * 10,2);
			$stusta->grade = $stu_grade;
			$edg_stusta[] = $stusta;
		}
		return $edg_stusta;
	}

	/**
	 * Save a new record or update a old one in the database.
	 */
	function save_or_update() {
		$edg = new object();
		$edg->courseid = $this->courseid;
		//$edg->polouab = $this->polouab;
		$edg->grandearea = $this->grandearea;
		$edg->status = $this->status;
		$edg->timestamp_last = $this->timestamp_last;
		$edg->timestamp_last_send = $this->timestamp_last_send;
		$edg->timemodified = $this->timemodified;

		//if ($this->recent) {
		if ($this->id == 0) {
			$this->id = local_insert_record("block_uabdatagatherer",$edg,true);
			foreach ($this->student_status as $edg_stusta) {
				local_insert_record("block_uabdatagatherer_stusta",$edg_stusta);
			}
		} else {
			$edg->id = $this->id;
			local_update_record("block_uabdatagatherer", $edg);
			foreach ($this->student_status as $edg_stusta) {
				if (isset($edg_stusta->id)) {
					local_update_record("block_uabdatagatherer_stusta",$edg_stusta);
				} else {
					local_insert_record("block_uabdatagatherer_stusta",$edg_stusta);
				}
			}
		}
	}

	/**
	 * Load the course's data from a record in the database.
	 */
	function load() {
		global $CFG, $DB;

		//$query = "SELECT id, courseid, polouab, grandearea, status, timestamp_last, timestamp_last_send, timemodified
		$query = "SELECT id, courseid, grandearea, status, timestamp_last, timestamp_last_send, timemodified
				  FROM {$CFG->prefix}block_uabdatagatherer
				  WHERE courseid = ".$this->courseid;
		$result = local_get_record_sql($query);
		$this->id = $result->id;
		//$this->polouab = $result->polouab;
		$this->grandearea = $result->grandearea;
		$this->status = $result->status;
		$this->timestamp_last = $result->timestamp_last;
		$this->timestamp_last_send = $result->timestamp_last_send;
		$this->timemodified = $result->timemodified;
	}

	/**
	 * Check if exists or not a record with id equal to $this->courseid.
	 *
	 * @return boolean
	 */
	function exists() {
		global $CFG;
		$query = "SELECT id
				  FROM {$CFG->prefix}block_uabdatagatherer
				  WHERE courseid = ".$this->courseid;
		if (local_get_record_sql($query)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Calculate a estimated date to the course completation date
	 *
	 * The completation date is last date where the log table shows a record for any
	 * of the course's students.
	 *
	 * @param int $courseid
	 * @return int A timestamp
	 */
	function estimate_course_completation_date($courseid) {
		// return last timestamp seen in log
		global $CFG;
		$studentsIds = $this->get_students_ids();
		if (count($studentsIds) == 0) { // We dont have any user with a student role in this course
			return usertime(time()); // Return the time now
		}
		$delimiter="";
		$students="";
		foreach ($studentsIds as $sid) {
			$students .= $delimiter.$sid;
			$delimiter = ",";
		}

		if (MOODLE_DETECTED_VERSION >= 26) {// Before 2.6 we wanna the log table, after 2.6 we wanna the logstore_standard_log
			$query = "SELECT timecreated AS timestamp_last
				FROM {$CFG->prefix}logstore_standard_log l
				WHERE l.courseid = {$courseid}
					AND l.userid IN ({$students})
				ORDER BY timestamp_last DESC
				LIMIT 1";
		} else {
			$query = "SELECT time AS timestamp_last
				FROM {$CFG->prefix}log l
				WHERE l.course = {$courseid}
					AND l.userid IN ({$students})
				ORDER BY timestamp_last DESC
				LIMIT 1";
		}
		$result = local_get_record_sql($query,false,true);
		$estimate = $result->timestamp_last;

		if (! is_null($estimate)) {
			return $estimate;
		} else {
			return usertime(time());
		}
	}

	/**
	 * Return a array of userid's of all the students in the course.
	 *
	 * @return array
	 */
    function get_students_ids() {
        global $CFG;
        $studentRoles=get_config("block_uabdatagatherer","StudentRoles");
        if ($studentRoles == "") {
        	error(" Erro: Student Roles need to be configured in the module.",$CFG->wwwroot.'/course/view.php?id='.$this->courseid);
        }
		// TODO Verficar se essa query funciona em todas as versões do moodle
        $query = "SELECT DISTINCT u.id AS userid, u.firstname, u.lastname
                  FROM {$CFG->prefix}user u
                  JOIN {$CFG->prefix}role_assignments ra ON ra.userid = u.id
                  JOIN {$CFG->prefix}context ct ON ct.id = ra.contextid AND ct.contextlevel = 50
                  JOIN {$CFG->prefix}course c ON c.id = ct.instanceid
                  JOIN {$CFG->prefix}role r ON r.id = ra.roleid AND r.id IN ({$studentRoles})
                  WHERE c.id = {$this->courseid}
                  ORDER BY u.firstname, u.lastname";

        $result = local_get_records_sql($query);
        $a_users = array();
        foreach ($result as $user) {
			$a_users[] = $user->userid;
		}
        return $a_users;
    }

}

/**
 * Returns the content of a URL as a string.
 *
 * @param string $url The URL to return the content
 * @return mixed Return false in case of error or the URL's content (as a string) in case of sucess.
 */
function getUrlContent($url){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_USERAGENT, 'UABDataGatherer');
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
	curl_setopt($ch, CURLOPT_TIMEOUT, 900);
	$data = curl_exec($ch);
	$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	curl_close($ch);
	return ($httpcode>=200 && $httpcode<300) ? $data : false;
}

/**
 * Local get_records function made to work in various versions of Moodle.
 *
 * @param mixed $table
 * @param mixed $field
 * @param mixed $value
 * @param mixed $sort
 * @param mixed $fields
 * @param mixed $limitfrom
 * @param mixed $limitnum
 * @return void
 */
function local_get_records($table, $field='', $value='', $sort='', $fields='*', $limitfrom='', $limitnum='') {
	switch (MOODLE_DETECTED_VERSION) {
		case 19: // Moodle 1.9
			return get_records($table, $field, $value, $sort, $fields, $limitfrom, $limitnum);
			break;
		default:
			global $DB;
			if ($field) {
				$conditions = array($field => $value);
			} else {
				$conditions = null;
			}
			return $DB->get_records($table, $conditions, $sort, $fields, $limitfrom, $limitnum);
			break;
	}
}

/**
 * Local get_record function made to work in various versions of Moodle.
 *
 * @param mixed $table
 * @param mixed $field1
 * @param mixed $value1
 * @param mixed $field2
 * @param mixed $value2
 * @param mixed $field3
 * @param mixed $value3
 * @param mixed $fields
 * @return mixed
 */
function local_get_record($table, $field1, $value1, $field2='', $value2='', $field3='', $value3='', $fields='*') {
	switch (MOODLE_DETECTED_VERSION) {
		case 19: // Moodle 1.9
			return get_record($table, $field1, $value1, $field2, $value2, $field3, $value3, $fields);
			break;
		default:
			global $DB;
			if ($field3) {
				$conditions = array($field1 => $value1, $field2 => $value2, $field3 => $value3);
			} elseif ($field2) {
				$conditions = array($field1 => $value1, $field2 => $value2);
			} elseif ($field1) {
				$conditions = array($field1 => $value1);
			} else {
				$conditions = null;
			}
			return $DB->get_record($table, $conditions, $fields);
			break;
	}
}

/**
 * Local get_records_sql function made to work in various versions of Moodle.
 *
 * @param string $sql
 * @param int $limitfrom
 * @param int $limitnum
 * @return mixed an array of objects, or false if no records were found or an error occured.
 */
function local_get_records_sql($sql, $limitfrom='', $limitnum='') {
	switch (MOODLE_DETECTED_VERSION) {
		case 19: // Moodle 1.9
			return get_records_sql($sql, $limitfrom, $limitnum);
			break;
		default:
			global $DB;
			if (! $limitfrom) $limitfrom = 0;
			if (! $limitnum) $limitnum = 0;
			return $DB->get_records_sql($sql, null, $limitfrom, $limitnum);
			break;
	}
}

/**
 * Local insert_record function made to work in various versions of Moodle
 *
 * @param string $table
 * @param object $dataobject
 * @param bool $returnid
 * @param string $primarykey (obsolete)
 */
function local_insert_record($table, $dataobject, $returnid=true, $primarykey='id') {
	switch (MOODLE_DETECTED_VERSION) {
		case 19: // Moodle 1.9
			return insert_record($table, $dataobject, $returnid, $primarykey);
			break;
		default:
			global $DB;
			return $DB->insert_record($table, $dataobject, $returnid);
			break;
	}
}

/**
 * Local get_record_sql function made to work in various versions of Moodle.
 *
 * @param string $sql
 * @param bool $expectmultiple
 * @param bool $nolimit
 * @return Found record as object. False if not found or error
 */
function local_get_record_sql($sql, $expectmultiple=false, $nolimit=false) {
	switch (MOODLE_DETECTED_VERSION) {
		case 19: // Moodle 1.9
			return get_record_sql($sql, $expectmultiple, $nolimit);
			break;
		default:
			global $DB;
			return $DB->get_record_sql($sql);
			break;
	}
}

/**
 * Local update_record function made to work in various versions of Moodle.
 *
 * @param string $table
 * @param object $dataobject
 * @return bool
 */
function local_update_record($table, $dataobject) {
	switch (MOODLE_DETECTED_VERSION) {
		case 19: // Moodle 1.9
			return update_record($table, $dataobject);
			break;
		default:
			global $DB;
			return $DB->update_record($table, $dataobject);
			break;
	}
}

/**
 * Local record_exists_select function made to work in various versions of Moodle.
 *
 * @param string $table
 * @param string $select
 * @return bool
 */
function local_record_exists_select($table, $select='') {
	switch (MOODLE_DETECTED_VERSION) {
		case 19: // Moodle 1.9
			return record_exists_select($table, $select);
			break;
		default:
			global $DB;
			return $DB->record_exists_select($table, $select);
			break;
	}
}

/**
 * Local delete_records function made to work in various versions of Moodle
 *
 * @param string $table
 * @param string $field1
 * @param string $value1
 * @param string $field2
 * @param string $value2
 * @param string $field3
 * @param string $value3
 * @return mixed
 */
function local_delete_records($table, $field1='', $value1='', $field2='', $value2='', $field3='', $value3='') {
	switch (MOODLE_DETECTED_VERSION) {
		case 19: // Moodle 1.9
			return delete_records($table, $field1, $value1, $field2, $value2, $field3, $value3);
			break;
		default:
			global $DB;
			if ($field3) {
				$conditions = array($field1 => $value1, $field2 => $value2, $field3 => $value3);
			} elseif ($field2) {
				$conditions = array($field1 => $value1, $field2 => $value2);
			} elseif ($field1) {
				$conditions = array($field1 => $value1);
			} else {
				$conditions = null;
			}
			return $DB->delete_records($table, $conditions);
			break;
	}
}

/**
 * Local count_records_sql function made to work in various versions of Moodle
 *
 * @param string $sql
 * @return int
 */
function local_count_records_sql($sql) {
	switch (MOODLE_DETECTED_VERSION) {
		case 19: // Moodle 1.9
			return count_records_sql($sql);
			break;
		default:
			global $DB;
			return $DB->count_records_sql($sql);
			break;
	}
}

/**
 * Local get_recordset_sql function made to work in various versions of Moodle
 *
 * @param string $sql the SQL select query to execute.
 * @param int $limitfrom return a subset of records, starting at this point (optional, required if $limitnum is set).
 * @param int $limitnum return a subset comprising this many records (optional, required if $limitfrom is set).
 * @return mixed an ADODB RecordSet object, or false if an error occured.
 */
function local_get_recordset_sql($sql, $limitfrom=null, $limitnum=null) {
	switch (MOODLE_DETECTED_VERSION) {
		case 19: // Moodle 1.9
			return get_recordset_sql($sql, $limitfrom, $limitnum);
			break;
		default:
			global $DB;
			if (is_null($limitfrom)) $limitfrom = 0;
			if (is_null($limitnum)) $limitnum = 0;
			return $DB->get_recordset_sql($sql, null, $limitfrom, $limitnum);
			break;
	}
}

/**
 * make_course_log_file function to create a zip file with the course's log in a CSV format
 *
 * @param int $courseid
 * @return bool success or failure
 */
function make_course_log_file ($courseid) {
	global $CFG;

	if (! $edg = new uabdatagatherer_course($courseid)) {// If ID is invalid return false
		mtrace ("EDG Erro");
		return false;
	}

	if ( $edg->status != 2) {// Status == 2 ==> Course's data processed, we can make the file
		mtrace ("EDG status erro");
		return false;
	}

	$query = "SELECT id, time, userid, ip, module, cmid, action, url, info
				FROM {$CFG->prefix}log l
				WHERE course = {$courseid} AND
				time <= {$edg->timestamp_last}
				ORDER By id;";

	if (MOODLE_DETECTED_VERSION >= 26) {// Before 2.6 we wanna the log table, after 2.6 we wanna the logstore_standard_log too if it is enabled
		$enabled_stores = get_config('tool_log', 'enabled_stores');
		if (preg_match("/logstore_standard/", $enabled_stores)) {
			$query2 = "SELECT id, eventname, component, action, target, objecttable, objectid, crud, edulevel, contextid, contextlevel, contextinstanceid, userid, relateduserid, anonymous, other, timecreated, origin, ip, realuserid
					   	FROM {$CFG->prefix}logstore_standard_log
						WHERE courseid = {$courseid} AND
								timecreated <= {$edg->timestamp_last}
						ORDER By id;";
		}
	}

	$data_dir=make_upload_directory('uabdata' . '/' . $courseid);
	$data_file = $data_dir .'/course_log.csv';
	$data_file2 = $data_dir .'/course_logstore_standard.csv';
	$zip_file = $data_dir .'/course_log.zip';

	if (! $file = fopen($data_file, 'w')) {// Could not create the data file
		mtrace ("fopen error");
		return false;
	}

	# CSV header
	$line = "courseid, time, userid, ip, module, cmid, action, url, info";
	fwrite($file, $line);

	# CSV data
	$result = local_get_recordset_sql($query);
	foreach ($result as $logline) {
		$line = "\n";
		$line .= $courseid.",";
		switch (MOODLE_DETECTED_VERSION) {
			case 19: // Moodle 1.9 returns a array
				$line .= $logline['time'].",";
				$line .= $logline['userid'].",";
				$line .= "\"".$logline['ip']."\",";
				$line .= "\"".$logline['module']."\",";
				$line .= $logline['cmid'].",";
				$line .= "\"".$logline['action']."\",";
				$line .= "\"".$logline['url']."\",";
				$line .= "\"".$logline['info']."\"";
				break;
			default: // After 1.9 returns a object
				$line .= $logline->time.",";
				$line .= $logline->userid.",";
				$line .= "\"".$logline->ip."\",";
				$line .= "\"".$logline->module."\",";
				$line .= $logline->cmid.",";
				$line .= "\"".$logline->action."\",";
				$line .= "\"".$logline->url."\",";
				$line .= "\"".$logline->info."\"";
				break;
		}
		fwrite($file, $line);
	}
	$result->close();
	fclose($file);

	if (isset($query2)) {
		if (! $file = fopen($data_file2, 'w')) {// Could not create the data file
			mtrace ("fopen error - 2");
			return false;
		}

		# CSV header
		$line = "courseid, eventname, component, action, target, objecttable, objectid, crud, edulevel, contextid, contextlevel, contextinstanceid, userid, relateduserid, anonymous, other, timecreated, origin, ip, realuserid";
		fwrite($file, $line);

		# CSV data
		$result = local_get_recordset_sql($query2);
		foreach ($result as $logline) {
			$line = "\n";
			$line .= $courseid.",";
			$line .= "\"".$logline->eventname."\",";
			$line .= "\"".$logline->component."\",";
			$line .= "\"".$logline->action."\",";
			$line .= "\"".$logline->target."\",";
			$line .= "\"".$logline->objecttable."\",";
			$line .= $logline->objectid.",";
			$line .= "\"".$logline->crud."\",";
			$line .= $logline->edulevel.",";
			$line .= $logline->contextid.",";
			$line .= $logline->contextlevel.",";
			$line .= $logline->contextinstanceid.",";
			$line .= $logline->userid.",";
			$line .= $logline->relateduserid.",";
			$line .= $logline->anonymous.",";
			$line .= "\"".$logline->other."\",";
			$line .= $logline->timecreated.",";
			$line .= "\"".$logline->origin."\",";
			$line .= "\"".$logline->ip."\",";
			$line .= $logline->realuserid;
			fwrite($file, $line);
		}
		$result->close();
		fclose($file);
	}

	if (isset($query2)) {
		$files = array ($data_file, $data_file2);
	} else {
		$files = array ($data_file);
	}
	zip_files ($files, $zip_file);
	if(file_exists($data_file)){
		unlink($data_file);
	}
	if(file_exists($data_file2)){
		unlink($data_file2);
	}
	return true;
}


/**
 * make_course_basket_file function to create a zip file with the course's basket in a CSV format
 *
 * @param int $courseid
 * @return bool
 */
function make_course_basket_file ($courseid) {
	global $CFG;

	if (! $edg = new uabdatagatherer_course($courseid)) // If ID is invalid return false
		return false;

	if ( $edg->status != 2) // Status == 2 ==> Course's data processed, we can make the file
		return false;

	$query = "SELECT id, label
		FROM {$CFG->prefix}block_uabdatagatherer_items";
	$items = local_get_records_sql($query);

	foreach ($items as $item) {
		$query = "SELECT id, userid, value
			FROM {$CFG->prefix}block_uabdatagatherer_basket b
			WHERE courseid = {$courseid}
			AND itemid = {$item->id}";
		$users = local_get_records_sql($query);
		if ($users) {
			foreach ($users as $user) {
				$basket[$user->userid][$item->label] = $user->value;
			}
		}
	}

	// Others itens to add to the basket
	$query = "SELECT s.id, s.userid as userid, u.grandearea as grandearea, s.polouab as polouab, s.status as status
		FROM {$CFG->prefix}block_uabdatagatherer u
			JOIN {$CFG->prefix}block_uabdatagatherer_stusta s ON u.courseid = s.courseid
		WHERE u.courseid = {$courseid}";
	// TODO acrescentar um check
	$users = local_get_records_sql($query);
	foreach ($users as $user) {
		$basket[$user->userid]["polouab"] = $user->polouab;
		$basket[$user->userid]["grandearea"] = $user->grandearea;
		$basket[$user->userid]["status"] = $user->status;
	}
	// We put moodle version in basket
	$moodleversion="Moodle_{$CFG->version}";

	$data_dir=make_upload_directory('uabdata' . '/' . $courseid);
	$data_file = $data_dir .'/course_basket.csv';
	$zip_file = $data_dir .'/course_basket.zip';
	if (! $file = fopen($data_file, 'w')) // Could not create the data file
		return false;

	# Print CSV header
	$line = "userid";
	foreach ($items as $item) {
		$line .= ",".$item->label;
	}
	$line .=",polouab,grandearea,moodleversion,status";
	fwrite($file, $line);

	# Print CSV data
	// TODO acrescentar um check
	foreach ($users as $user) {
		$line = "\n".$user->userid;
		foreach ($items as $item) {
			if (isset($basket[$user->userid][$item->label])) {
				$line .= ",".$basket[$user->userid][$item->label];
			} else {
				$line .= ",0";
			}
		}
		$line .= ",".$basket[$user->userid]["polouab"];
		$line .= ",".$basket[$user->userid]["grandearea"];
		$line .= ",".$moodleversion;
		$line .= ",".$basket[$user->userid]["status"];
		fwrite($file, $line);
	}

	fclose($file);
	zip_files (array(1 => $data_file), $zip_file);
	if(file_exists($data_file)){
		unlink($data_file);
	}
	return true;
}

/**
 * Function to recursively remove a directory. Got from example in http://br1.php.net/manual/pt_BR/function.rmdir.php
 *
 * @param string $src path to the directory
 */
function rrmdir($src) {
	$dir = opendir($src);
	while(false !== ( $file = readdir($dir)) ) {
		if (( $file != '.' ) && ( $file != '..' )) {
			$full = $src . '/' . $file;
			if ( is_dir($full) ) {
				rrmdir($full);
			}
			else {
				unlink($full);
			}
		}
	}
	closedir($dir);
	rmdir($src);
}

function cronjobIsExecuting($timestart=0,$maxruntime=0) {
	$data_dir=make_upload_directory('uabdata');
	$cron_file = $data_dir .'/cronjob';

	if (is_writable($cron_file)) { // File exist and is writable, we need test if timestamp is expired or not.
		$timestamp = file_get_contents($cron_file);
		$timestamp = is_numeric($timestamp)? $timestamp : 0;
		$timediff = $timestart - $timestamp;
		//echo "timestart = $timestart / timediff= $timediff / timestamp = $timestamp / maxruntime = " . $maxruntime * HOURSECS; die();
		if ($timediff <= ($maxruntime * HOURSECS)) { // Not expired.
			return true;
		} else { // Expired.
			file_put_contents($cron_file, $timestart);
			return false; // false = cronjob not running
		}
	} elseif (file_put_contents($cron_file, $timestart)) { // If we can create a file we create and return false
		return false; // false = cronjob not running
	} else { // If not, we got some erro and is better not to run the cronjob.
		mtrace("Error writing {$cron_file}. Cronjob will not be executed.");
		return true; // true = not run the cronjob
	}
}

function removeCronjobFile() {
	// Remove cronjob file
	$data_dir=make_upload_directory('uabdata');
	$cron_file = $data_dir .'/cronjob';
	if (is_file($cron_file)) { // If file exists we remove it
		if (! unlink($cron_file)) {
			mtrace("Erro: couldn't remove file {$cron_file}.");
		}
	}
}

/**
* Parse out url query string into an associative array
*
* $qry can be any valid url or just the query string portion.
* Will return false if no valid querystring found
*
* @param $qry String
* @return Array
*/

function queryToArray($qry){

		$result = array();
		//string must contain at least one = and cannot be in first position
		if(strpos($qry,'=')) {

			if(strpos($qry,'?')!==false) {
			$q = parse_url($qry);
			$qry = $q['query'];
			}
		}else {
				return false;
		}

		foreach (explode('&', $qry) as $couple) {
				list ($key, $val) = explode('=', $couple);
				$result[$key] = $val;
		}

		return empty($result) ? false : $result;
}


/**
 * Function to check if a timestamp is valid
 *
 * @param string $timestamp 
 * @return Boolean
 */

function isValidTimeStamp($timestamp)
{
    return ((string) (int) $timestamp === $timestamp) 
        && ($timestamp <= PHP_INT_MAX)
        && ($timestamp >= ~PHP_INT_MAX);
}


/**
 * Function to create or load data object created before and set a status to request
 *
 * @param string $from_datetime 
 * @param int $iesid 
 * @param object &$courses (reference)
 */

function createOrLoadJsonObject($from_datetime, $until_datetime, $iesid, &$courses) {
	global $CFG, $DB;
	$request = new Request();

	//pega a request mais antiga com status started
	$started = $request->getOneByStatus("started");
	
	//se encontrou alguma started e a request mais antiga criada tiver o update date diferente da atual, adiciona na fila
	if(isset($started[0]) && $started[0]->from_datetime != $from_datetime) {	
		$request->createQueued($from_datetime, $until_datetime);
	}
	
	if($started == null){ //se não tiver nenhum pendente verifica se tem algum na fila
		
		$queued = $request->getOneByStatus("queued");

		if($queued == null){ //fila vazia, adiciona como started
			$requestData = [
				"from_datetime" => $from_datetime,
				"status" => "started",
				"created_at" => time()
			];
			$request_id = $request->create("started", $from_datetime, $until_datetime);
		}
		else{//fila não vazia
			//verfica se tem algum na fila
			//se tiver, e o from_datetime for diferente adiciona o atual na fila, pois já tinha um na fila antes
			
			if(isset($queued[0]) && $queued[0]->from_datetime != $from_datetime) {	
				$request->createQueued($from_datetime, $until_datetime);
			}
			
			//altera o que foi adicionado na fila antes para started
			$request_id = $queued[0]->id;
			$from_datetime = $queued[0]->from_datetime;
			$request->setById($request_id, "started");				
			
			
		}
		require ("{$CFG->dirroot}/blocks/uabdatagatherer/array/ies.php");
		$iesid = intval($iesid);
		foreach ($ies as $key => $val) {
			if (intval($val['uabid']) == $iesid) {
				$iesFounded = $val;
				break;
			}
		}

		$CFG->uabdata = [
			"moodle_version" => $CFG->release,
			"from_datetime" => $from_datetime,
			"until_datetime" => $until_datetime,
			"update_date_id" => $request_id,
			"ies" => [
				"uab_ies_id" => $iesFounded['uabid'],
				"name" => $iesFounded['nome'],
				"abbreviation" => $iesFounded['sigla']
			]
		];

		initUabCourses($courses);
	}
	else{//carrega arquivo salvo anteriormente		
		$started = array_values($started);
		$filePath=make_upload_directory('uabdata' . '/');
		$filePath = sprintf("%s%s.json",$filePath, $started[0]->id);
		
		if (file_exists($filePath)){
			$jsonData = file_get_contents($filePath);
			$obj = json_decode($jsonData, true);   
			if (!empty($obj)){
				$CFG->uabdata = $obj;
			}
			else{
				$request->setById($started[0]->id, "queued");		
				mtrace ("Error: started file is empty");
				return false;
			}
		}
		else{
			$request->setById($started[0]->id, "queued");
			mtrace ("Error: started file does not exist");
			return false;
		}
		
	}	
}

/**
 * Function to set all courses to queud and add to CFG->uabdata object
 *
 * @param object &$courses (reference)
 */

function initUabCourses(&$courses) {
	global $CFG;
	foreach ($courses as $key => $course){
		$CFG->uabdata["courses"][] = [
			"uab_course_id" => $course->uab_id, 
			"course_name" => $course->name
		];
		$data = [
			"id" => $course->id,
			"status" => "queued"
		];
		$courses[$key]->status = "queued";
		local_update_record("block_uabdatagatherer_course", $data);

		setStatusSubjectsByCourse($course->uab_id, $courses[$key]->status);
	}
}

/**
 * Function to get users by a course and an array of roles
 *
 * @param int $courseid
 * @param array $userRoles
 * @return Array
 */

function getUsersByCourseAndRoles($courseid, $userRoles) {
	global $DB, $CFG;
	$roles ="";
	$array_users = [];
	// $context = get_context_instance( CONTEXT_COURSE, $courseid );
	$context = context_course::instance($courseid);


	foreach ($userRoles as $role) {
		if($roles == ""){
			$roles = '( roleid='.$role;
		}
		else{
			$roles = $roles. ' or roleid='.$role;
		}		
	}
	$roles = $roles.')';
	
	$query = 'SELECT username, u.id as user_id, firstname, lastname, email, '. $courseid .' as courseid, 999 as polouab, 0 as status, 0 as timemodifiedab
		FROM mdl_role_assignments as a, mdl_user as u 
		WHERE contextid=' . $context->id .' and '. $roles .'and a.userid=u.id;';

	$result = $DB->get_records_sql( $query );
	
	$users = array_values($result);
	foreach ($users as $user) {
		$array_users[] = (array)$user;
	}
	return $array_users;

}

function setUsersByCourseId($courseid, $array_index, $subject_index) {
	global $CFG;
	//monta os alunos
	$roles = explode(",", get_config("block_uabdatagatherer","StudentRoles"));

	if( empty($roles[0])){
		$students = [];
	}
	else{
		$students = getUsersByCourseAndRoles($courseid, $roles);
	}
	
	$CFG->uabdata['courses'][$array_index]['subjects'][$subject_index]['users']['students'] = $students;

	//monta os tutores ead
	$roles = explode(",", get_config("block_uabdatagatherer","TutorEADRoles"));

	if( empty($roles[0])){
		$tutorsEad = [];
	}
	else{
		$tutorsEad = getUsersByCourseAndRoles($courseid, $roles);
	}
	
	$CFG->uabdata['courses'][$array_index]['subjects'][$subject_index]['users']['tutors_ead'] = $tutorsEad;


	//monta os professores formadores
	$roles = explode(",", get_config("block_uabdatagatherer","TeacherFormerRoles"));
	if( empty($roles[0])){
		$teacherFormers = [];
	}
	else{	
		$teacherFormers = getUsersByCourseAndRoles($courseid, $roles);
	}
	
	$CFG->uabdata['courses'][$array_index]['subjects'][$subject_index]['users']['teacher_formers'] = $teacherFormers;

	//monta os tutores presenciais
	$roles = explode(",", get_config("block_uabdatagatherer","TutorPresentialRoles"));
	if( empty($roles[0])){
		$tutorPresential = [];
	}
	else{	
		$tutorPresential = getUsersByCourseAndRoles($courseid, $roles);
	}
	
	$CFG->uabdata['courses'][$array_index]['subjects'][$subject_index]['users']['tutors_presential'] = $tutorPresential;

	//monta os professores conteúdistas
	$roles = explode(",", get_config("block_uabdatagatherer","TeacherContentist"));
	if( empty($roles[0])){
		$teacherContentist = [];
	}
	else{
		$teacherContentist = getUsersByCourseAndRoles($courseid, $roles);
	}
	
	$CFG->uabdata['courses'][$array_index]['subjects'][$subject_index]['users']['teacher_contentist'] = $teacherContentist;
}


function getAllSubjets(){
	global $DB,$CFG;

	$query = "SELECT id, fullname FROM {$CFG->prefix}course;";
	
	return array_values(local_get_records_sql( $query ));
}

function getAllSubjectsByCategory($id){
	global $DB,$CFG;
	$query1 = "SELECT id, fullname FROM {$CFG->prefix}course WHERE category = {$id};";
	$query2 = "SELECT id, name FROM {$CFG->prefix}course_categories WHERE parent = {$id};";
	$result = local_get_records_sql( $query1 );
	$subjects = array();
	if (count($result) != 0){
		foreach ($result as $key => $value) {
			$subjects[$key] = $value->fullname;
		}
	}

	$result2 = local_get_records_sql( $query2 );
	if (count($result2) == 0){
		return $subjects;
	}
	foreach ($result2 as $key => $value) {
		$subjects = $subjects + getAllSubjectsByCategory($value->id);
	}
	return $subjects;
}

function getAllSubjectsByRootUABCategory(){
	global $DB,$CFG;

	$categories = explode(",", get_config("block_uabdatagatherer","RootUABCourses"));
	$subjects = array(); 
	foreach ($categories as $category) {
		$subjects = $subjects + getAllSubjectsByCategory($category);
	}

	$subs = array();
	foreach ($subjects as $key => $value) {
		$subject = new stdClass();
		$subject->id = $key;
		$subject->fullname = $value;
		$subs[] = $subject;
	}
	// uasort($subjects, function ($a, $b) {
    // return strcmp($a, $b);
    // //Se quiser inverter a ordem basta trocar por return strcmp($b, $a);
	// });
	
	return $subs;
}

function getAllSubjectsByCourseUABCategory(){

}

function getAllCoursesConfigured(){
	global $DB,$CFG;

	$query = "SELECT *
	FROM {$CFG->prefix}block_uabdatagatherer_course";
	
	return local_get_records_sql( $query );
}

function downloadJson(){
	global $CFG;
	$data_dir=make_upload_directory('uabdata' . '/');
	//$data_file = $data_dir .'/course_basket.csv';
	$json_file = $data_dir .'/data.json';
	$fp = fopen($json_file, 'w');
	fwrite($fp, json_encode($CFG->uabdata));
	fclose($fp);
	
	//*/ disable caching
	$now = gmdate("D, d M Y H:i:s");
	header("Expires: Fri, 01 Jan 2016 00:00:00 GMT");
	header("Cache-Control: max-age=0, no-cache, must-revalidate, proxy-revalidate");
	header("Last-Modified: {$now} GMT");
	
	// force download
	header("Content-Type: application/force-download");
	header("Content-Type: application/octet-stream");
	header("Content-Type: application/download");
	
	// disposition / encoding on response body
	header("Content-Disposition: attachment;filename=data.json");
	header("Content-Transfer-Encoding: binary");
	header('Content-Length: ' . filesize($json_file));
	//*/
	readfile($json_file);
	unlink($json_file);
	
	$data = [
		"id" => $CFG->uabdata['update_date_id'],
		"status" => "processed"
	];
	local_update_record("block_uabdatagatherer_rquest", $data);
	$filePath=make_upload_directory('uabdata' . '/');	
	$json_file = sprintf("%s%s.json",$filePath, $CFG->uabdata['update_date_id']);
	if (file_exists($json_file)){
		unlink($json_file);
	}
	
}

function saveJsonFile(){
	global $CFG;
	
	$filePath=make_upload_directory('uabdata' . '/');
	if (is_writable($filePath)) {
		$json_file = sprintf("%s%s.json",$filePath, $CFG->uabdata['update_date_id']);
		if(file_exists($json_file)){
			unlink($json_file);
		}
		$fp = fopen($json_file, 'w');
		fwrite($fp, json_encode($CFG->uabdata));
		fclose($fp);
		if(file_exists($json_file)){
			return true;
		}
		
	}		
	return false;
	
	
}


function getAllSubjectsFromUABCourse($uab_id){
	global $DB,$CFG;
	$query = "SELECT s.*, c.fullname FROM {$CFG->prefix}block_uabdatagatherer_subjec s
	JOIN {$CFG->prefix}course c ON subject_id = c.id
	WHERE s.uab_id = ".$uab_id.";";
	return local_get_records_sql( $query );
}

function getAllCategoriesNonLeaf(){
	global $CFG;
	$query = "SELECT id, name FROM {$CFG->prefix}course_categories WHERE coursecount = 0 ORDER BY name";
	return local_get_records_sql( $query );
}

function getAllCategories(){
	global $CFG;
	$query = "SELECT id, name FROM {$CFG->prefix}course_categories ORDER BY name";
	return local_get_records_sql( $query );
}

function getCategoriesByCategory($id){
	global $DB,$CFG;
	$query = "SELECT id, name, depth FROM {$CFG->prefix}course_categories WHERE parent = {$id};";
	$result = local_get_records_sql( $query );

	$categories = array();
	if (count($result) == 0){
		return $categories;
	}
	// echo "<pre>";
	// var_dump($result);
	// die;
	foreach ($result as $key => $value) {
		$categories[$key] = str_repeat("-", $value->depth).$value->name;
		$categories = $categories + getCategoriesByCategory($value->id);
	}
	return $categories;
}

function getAllCategoriesFromRootCategory(){
	global $DB,$CFG;
	$categories = explode(",", get_config("block_uabdatagatherer","RootUABCourses"));
	$cats = array(); 
	foreach ($categories as $category) {
		$cats = $cats + getCategoriesByCategory($category);
	}
	return $cats;
}

function getRootCategory($id){
	global $DB,$CFG;
	$query = "SELECT root_category FROM {$CFG->prefix}block_uabdatagatherer_course WHERE id=$id;";
	$result = local_get_record_sql($query);
	return $result->root_category;
}

function setStatusSubjectsByCourse($uab_id, $status){
	global $DB,$CFG;	
	$query = "UPDATE {$CFG->prefix}block_uabdatagatherer_subjec SET status = '{$status}' WHERE uab_id=$uab_id";
	return $DB->execute($query);
}

